import java.time.LocalDate;


public class PrintedBook extends Book{
    private boolean isBorrowed = false;
    private LocalDate borrowingDate;
    private int borrowerID;

    public PrintedBook(){
        super(true);
        this.borrowerID = 0;
    }

    public void borrowBook(){
        isBorrowed = true;
    }
    public void returnBook(){
        isBorrowed = false;
        setBorrowerID(0);
    }
    public boolean getIsBorrowed(){
        return isBorrowed;
    }
    public void setBorrowingDate(LocalDate date){
        borrowingDate = date;
    }
    public LocalDate getBorrowingDate(){
        return borrowingDate;
    }
    public void setBorrowerID(int borrowerID){
        this.borrowerID = borrowerID;
    }
    public int getBorrowerID(){return borrowerID;}
}
