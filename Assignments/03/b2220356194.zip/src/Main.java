public class Main {
    public static void main(String[] args) throws Exception {
        String path = args[0];
        String[] file = ReadWriteText.readFile(path);
        ReadWriteText.writer(Library.commandReader(file));
    }
}