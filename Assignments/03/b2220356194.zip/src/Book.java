import java.time.LocalDate;

public class Book {
    private static int bookIdCounter = 1;
    private final int bookID;
    private boolean isRead = false;
    private LocalDate readingDate;
    private final boolean isPrinted;
    private int readerID;
    private LocalDate deadline;

    public Book(boolean isPrinted){
        this.bookID = bookIdCounter++;
        this.isPrinted = isPrinted;
    }

    public int getBookID(){
        return bookID;
    }
    public void readBook(){
        isRead = true;
    }
    public void returnReadBook(){
        isRead = false;
    }
    public boolean isRead(){
        return isRead;
    }
    public boolean getIsPrinted(){
        return isPrinted;
    }
    public void setReadingDate(LocalDate date){
        readingDate = date;
    }
    public LocalDate getReadingDate(){
        return readingDate;
    }
    public void setReaderID(int readerID){
        this.readerID = readerID;
    }
    public int getReaderID(){return readerID;}
    public void setDeadline(LocalDate date){
        deadline = date;
    }
    public LocalDate getDeadline(){return deadline;}
}
