public class Student extends Member {
    public Student() {
        super(2,7, true);
    }
}
