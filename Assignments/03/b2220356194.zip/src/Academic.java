public class Academic extends Member {
    public Academic() {
        super(4,14, false);
    }
}
