public class Member {
    private static int memberIdCounter = 1;
    private final int memberID;
    private int bookLimit;
    private final int timeLimit;
    private int fee = 0;
    private int extensions = 1;
    private final boolean isStudent;
    public Member(int bookLimit, int timeLimit, boolean isStudent) {
        this.memberID = memberIdCounter++;
        this.bookLimit = bookLimit;
        this.timeLimit = timeLimit;
        this.isStudent = isStudent;
    }

    public void checkBookLimit() {
        bookLimit--;
    }
    public int getMemberID() {
        return memberID;
    }
    public int getBookLimit() {
        return bookLimit;
    }
    public int getTimeLimit() {
        return timeLimit;
    }
    public void setFee(int fee){
        this.fee = fee;
    }
    public int getFee(){
        return fee;
    }
    public void extend() {
        extensions--;
    }
    public int getExtensions(){
        return extensions;
    }
    public boolean getIsStudent(){
        return isStudent;
    }
}