public class HandWrittenBook extends Book{
    public HandWrittenBook(){
        super(false);
    }

}
