import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Library {
    static HashMap<Integer, Book> books = new HashMap<>();
    static HashMap<Integer, Member> members = new HashMap<>();


    public Library() {
        books = new HashMap<>();
        members = new HashMap<>();
    }

    public static String commandReader(String[] file) {
        // Method to understand the input
        StringBuilder sb = new StringBuilder();
        for (String input : file) {
            String[] tokens = input.split("\\s+");
            if (tokens.length == 0) {
                continue;
            }
            String command = tokens[0];
            switch (command) {
                case "addBook":
                    sb.append(addBook(tokens[1]));
                    break;
                case "addMember":
                    sb.append(addMember(tokens[1]));
                    break;
                case "borrowBook":
                    sb.append(borrowBook(Integer.parseInt(tokens[1]),Integer.parseInt(tokens[2]),tokens[3]));
                    break;
                case "returnBook":
                    sb.append(returnBook(Integer.parseInt(tokens[1]),Integer.parseInt(tokens[2]),tokens[3]));
                    break;
                case "extendBook":
                    sb.append(extendBook(Integer.parseInt(tokens[1]),Integer.parseInt(tokens[2]),tokens[3]));
                    break;
                case "readInLibrary":
                    sb.append(readInLibrary(Integer.parseInt(tokens[1]),Integer.parseInt(tokens[2]),tokens[3]));
                    break;
                case "getTheHistory":
                    sb.append(getTheHistory());
                    break;
            }
        }
        return String.valueOf(sb);
    }

    public static String addBook(String bookType) {
        Book book = bookType.equals("P") ? new PrintedBook() : new HandWrittenBook();
        int bookID = book.getBookID();
        books.put(bookID, book);
        return String.format("Created new book: %s [id: %d]\n", bookType.equals("P") ? "Printed" : "Handwritten", bookID);
    }

    public static String addMember(String memberType) {
        Member member = memberType.equals("S") ? new Student() : new Academic();
        int memberID = member.getMemberID();
        members.put(memberID, member);
        return String.format("Created new member: %s [id: %d]\n", memberType.equals("S") ? "Student" : "Academic", memberID);
    }

    public static String borrowBook(int bookId, int memberId, String date) {
        try {
            Book book = books.get(bookId);
            if (book == null) {
                throw new Exception("Book not found!");
            }

            Member member = members.get(memberId);
            if (member == null) {
                throw new Exception("Member not found!");
            }

            if (member.getBookLimit() <= 0) {
                throw new Exception("You have exceeded the borrowing limit!");
            }

            if (book instanceof PrintedBook) {
                PrintedBook printedBook = (PrintedBook) book;
                if (printedBook.getIsBorrowed()) {
                    throw new Exception("This book cannot be borrowed!");
                }

                printedBook.borrowBook();
                member.checkBookLimit();
                printedBook.setBorrowingDate(LocalDate.parse(date));
                printedBook.setDeadline(LocalDate.parse(date).plusDays(member.getTimeLimit()));
                printedBook.setBorrowerID(memberId);
                return "The book [" +bookId+ "] was borrowed by member ["+memberId+"] at "+date+"\n";
            }

            throw new Exception("This book cannot be borrowed!");

        } catch (Exception e) {
            return e.getMessage()+"\n";
        }
    }

    public static String returnBook(int bookId, int memberId, String date) {
        // return a borrowed book to the library and update the book and member's status
        try {
            if (!books.containsKey(bookId)) {
                throw new Exception("Book not found!");
            }
            Book book = books.get(bookId);

            if (!members.containsKey(memberId)) {
                throw new Exception("Member not found!");
            }
            Member member = members.get(memberId);

            if (book.isRead()) { // to return a book read in the library
                book.returnReadBook();
                return "The book [" + bookId + "] was returned by member [" + memberId + "] at " + date + " Fee: 0\n";

            } else { // to return a book that's been borrowed
                if (book instanceof PrintedBook) {
                    PrintedBook printedBook = (PrintedBook) book;
                    LocalDate currentDate = LocalDate.parse(date);
                    long duration = ChronoUnit.DAYS.between(printedBook.getBorrowingDate(), currentDate);
                    if (duration > member.getTimeLimit()) { // if the member exceeds the deadline
                        member.setFee((int) Math.abs(ChronoUnit.DAYS.between(printedBook.getDeadline(), currentDate)));
                        printedBook.returnBook();
                        return "You must pay a penalty!\n" +
                                "The book [" + bookId + "] was returned by member [" + memberId + "] at " + date + " Fee: " + member.getFee() + "\n";
                    } else {
                        printedBook.returnBook();
                        return "The book [" + bookId + "] was returned by member [" + memberId + "] at " + date + " Fee: " + member.getFee() + "\n";
                    }
                } else {
                    throw new Exception("This book cannot be returned!");
                }
            }

        } catch (Exception e) {
            return e.getMessage() + "\n";
        }
    }


    public static String extendBook(int bookId, int memberId, String currentDate) {
        try {
            Book book = books.getOrDefault(bookId, null);
            if (book == null) {
                throw new Exception("Book not found!");
            }

            Member member = members.getOrDefault(memberId, null);
            if (member == null) {
                throw new Exception("Member not found!");
            }

            if (member.getExtensions() <= 0) {
                throw new Exception("You cannot extend the deadline!");
            }

            if (book.isRead()) {
                throw new Exception("This book cannot be extended!");
            }

            PrintedBook printedBook = (PrintedBook) book;
            LocalDate newDeadline = printedBook.getDeadline().plusDays(member.getTimeLimit());
            printedBook.setDeadline(newDeadline);
            member.extend();

            return "The deadline of book [" + bookId + "] was extended by member [" + memberId + "] at " + currentDate + "\nNew deadline of book [" + bookId + "] is " + newDeadline + "\n";

        } catch (Exception e) {
            return e.getMessage() + "\n";
        }
    }

    public static String readInLibrary(int bookId, int memberId, String date) {
        // allow a member to read a book in the library without borrowing it
        try {
            Book book = books.get(bookId);
            if (book == null) {
                throw new Exception("Book not found!");
            }

            Member member = members.get(memberId);
            if (member == null) {
                throw new Exception("Member not found!");
            }

            LocalDate currentDate = LocalDate.parse(date);

            if (book.isRead()) {
                throw new Exception("You cannot read this book!");
            }
            if (member.getIsStudent() && !book.getIsPrinted()) {
                throw new Exception("Students cannot read handwritten books!");
            }
            if (book instanceof PrintedBook) {
                PrintedBook printedBook = (PrintedBook) book; // downcasting
                if (printedBook.getIsBorrowed() || printedBook.isRead()) {
                    throw new Exception("You cannot read this book!");
                }
            }

            book.readBook();
            book.setReadingDate(currentDate);
            book.setReaderID(memberId);

            return "The book ["+bookId+"] was read in library by member ["+memberId+"] at "+date+"\n";
        } catch (Exception e) {
            return e.getMessage() + "\n";
        }
    }


    public static String getTheHistory() {
        // print the history of all the book transactions in the library
        // get data of members
        int student = 0;
        int academic = 0;
        ArrayList<Integer> students = new ArrayList<>();
        ArrayList<Integer> academics = new ArrayList<>();
        for (Map.Entry<Integer, Member> entry : members.entrySet()) {
            Integer memberId =  entry.getKey();
            Member member = entry.getValue();
            if (member.getIsStudent()){
                student++;
                students.add(memberId);
            }else{
                academic++;
                academics.add(memberId);
            }
        }

        // get data of books
        int printedBook = 0;
        int handWrittenBook = 0;
        int borrowedBook = 0;
        int readBook = 0;
        ArrayList<PrintedBook> borrowedBooks = new ArrayList<>();
        ArrayList<Integer> handWrittenBooksID = new ArrayList<>();
        ArrayList<Integer> printedBooksID = new ArrayList<>();
        ArrayList<Book> readBooks = new ArrayList<>();
        for (Map.Entry<Integer, Book> entry : books.entrySet()) {
            Integer bookId =  entry.getKey();
            Book book = entry.getValue();
            if (book.getIsPrinted()){
                printedBook++;
                printedBooksID.add(bookId);
                if (book instanceof PrintedBook) {
                    PrintedBook pBook = (PrintedBook) book;
                    if (pBook.getIsBorrowed()){
                        borrowedBook++;
                        borrowedBooks.add(pBook);
                    }
                }
            }else{
                handWrittenBook++;
                handWrittenBooksID.add(bookId);
            }
            if (book.isRead()){
                readBook++;
                readBooks.add(book);
            }
        }

        // The final report
        StringBuilder sb = new StringBuilder();
        sb.append("History of library:\n\n");
        sb.append("Number of students: ").append(student).append("\n");
        for (int i : students) {
            sb.append("Student [id: ").append(i).append("]\n");
        }
        sb.append("\n");
        sb.append("Number of academics: ").append(academic).append("\n");
        for (int i : academics) {
            sb.append("Academic [id: ").append(i).append("]\n");
        }
        sb.append("\n");
        sb.append("Number of printed books: ").append(printedBook).append("\n");
        for (int i : printedBooksID) {
            sb.append("Printed [id: ").append(i).append("]\n");
        }
        sb.append("\n");
        sb.append("Number of handwritten books: ").append(handWrittenBook).append("\n");
        for (int i : handWrittenBooksID) {
            sb.append("Handwritten [id: ").append(i).append("]\n");
        }
        sb.append("\n");
        sb.append("Number of borrowed books: ").append(borrowedBook).append("\n");
        for (PrintedBook item : borrowedBooks) {
            sb.append("The book [").append(item.getBookID()).append("] was borrowed by member [")
                    .append(item.getBorrowerID()).append("] at ").append(item.getBorrowingDate()).append("\n");
        }
        sb.append("\n");
        sb.append("Number of books read in library: ").append(readBook).append("\n");
        for (Book item : readBooks) {
            sb.append("The book [").append(item.getBookID()).append("] was read in library by member [")
                    .append(item.getReaderID()).append("] at ").append(item.getReadingDate()).append("\n");
        }
        sb.append("\n");
        return String.valueOf(sb);
    }
}