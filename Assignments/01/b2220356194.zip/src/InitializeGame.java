public class InitializeGame {
    public static int score = 0;
    public static String[][] createBoard(String[] results) {
        // function to turn a list into 2D list
        int numRows = results.length;
        int numCols = results[0].split("\\s+").length;
        String[][] board = new String[numRows][numCols];
        for (int i = 0; i < numRows; i++) {
            String[] rowValues = results[i].split("\\s+");
            for (int j = 0; j < numCols; j++) {
                board[i][j] = rowValues[j];
            }
        }
        return board;
    }


    public static int[] locateCurrentCell(String[][] board) {
        // function to locate * on the board
        int rowIndex = 0;
        int colIndex = 0;
        for (String[] row : board) {
            for (String cell : row) {
                if (cell.equals("*")) {
                    return new int[] {rowIndex, colIndex};
                }
                colIndex++;
            }
            rowIndex++;
            colIndex = 0;
        }
        // "" not found - return default value of (0,0)
        return new int[] {0,0};
    }

    public static String contentChecker(int newRowIndex,int newColIndex, String[][] board) {
        // function to check the content of the new cell
        if (newRowIndex < 0 || newRowIndex >= board.length || newColIndex < 0 || newColIndex >= board[newRowIndex].length) {
            return null;
        }

        return board[newRowIndex][newColIndex];

    }


    public static void contentProcessing(String content, String[][] board, int newRowIndex, int newColIndex, char movement) {
        // Function to make changes on the board
        // Get the current cell coordinates
        int[] currentCell = locateCurrentCell(board);
        int currentRowIndex = currentCell[0];
        int currentColIndex = currentCell[1];

        // Check if content is not null
        if (content != null) {

            // Process content based on its value
            switch (content) {
                case "H":
                    board[currentRowIndex][currentColIndex] = " ";
                    haltGame(board);
                    System.exit(0);
                    break;
                case "B":
                    board[currentRowIndex][currentColIndex] = "X";
                    score -= 5;
                    board[newRowIndex][newColIndex] = "*";
                    break;
                case "R":
                    board[currentRowIndex][currentColIndex] = "X";
                    score += 10;
                    board[newRowIndex][newColIndex] = "*";
                    break;
                case "Y":
                    board[currentRowIndex][currentColIndex] = "X";
                    score += 5;
                    board[newRowIndex][newColIndex] = "*";
                    break;
                case "G":
                case "P":
                case "O":
                case "D":
                case "L":
                case "F":
                case "N":
                case "X":
                    board[currentRowIndex][currentColIndex] = content;
                    board[newRowIndex][newColIndex] = "*";
                    break;
                case "W":
                    // Move to a new cell and process its content
                    switch (movement) {
                        case 'L':
                            newColIndex += 2;
                            break;
                        case 'R':
                            newColIndex -= 2;
                            break;
                        case 'U':
                            newRowIndex += 2;
                            break;
                        case 'D':
                            newRowIndex -= 2;
                            break;
                    }
                    String newContent = contentChecker(newRowIndex, newColIndex, board);
                    contentProcessing(newContent, board, newRowIndex, newColIndex, movement);
                    break;
            }
        }
    }

    public static void haltGame(String[][] board){
        // This function is called if "*" falls into the Hole
        System.out.println("\nYour output is:");
        WriteToFile.writeUsingFileWriter("\nYour output is:\n");
        for (String[] line : board) {
            for (String cell : line) {
                System.out.print(cell + " ");
                WriteToFile.writeUsingFileWriter(cell + " ");
            }
            System.out.println();
            WriteToFile.writeUsingFileWriter("\n");
        }
        System.out.println();
        WriteToFile.writeUsingFileWriter("\n");
        System.out.println("Game over!");
        WriteToFile.writeUsingFileWriter("Game over!");
        System.out.println("Score: " + score);
        WriteToFile.writeUsingFileWriter("\nScore: " + score);
    }

    public static String[][] playGame(String[] results, String move) {
        // function to implement the game
        score = 0;
        String[][] board = createBoard(results);
        if (board.length == 0 || board[0].length == 0) {
            return board; // Handle empty board case
        }
        int[] currentCell = locateCurrentCell(board); // locate * on the board
        int currentRowIndex = currentCell[0];
        int currentColIndex = currentCell[1];
        // loop over the contents of move.txt
        for (char movement : move.toCharArray()) {
            int newRowIndex = currentRowIndex;
            int newColIndex = currentColIndex;
            // locate the new cell to which the * has to move according to move.txt
            switch (movement) {
                case 'L':
                    newColIndex = Math.max(currentColIndex - 1, 0);
                    break;
                case 'R':
                    newColIndex = Math.min(currentColIndex + 1, board[0].length - 1);
                    break;
                case 'U':
                    newRowIndex = Math.max(currentRowIndex - 1, 0);
                    break;
                case 'D':
                    newRowIndex = Math.min(currentRowIndex + 1, board.length - 1);
                    break;
            }
            if (newRowIndex != currentRowIndex || newColIndex != currentColIndex) {
                if (newRowIndex >= 0 && newRowIndex < board.length && newColIndex >= 0 && newColIndex < board[0].length) {
                    // Check the content of the new cell to which * has to move
                    String content = contentChecker(newRowIndex, newColIndex, board);
                    // make the changes on the board according to the content of the new cell
                    contentProcessing(content, board, newRowIndex, newColIndex, movement);
                    // locate * on the board after the changes have been made
                    currentCell = locateCurrentCell(board);
                    currentRowIndex = currentCell[0];
                    currentColIndex = currentCell[1];
                }
            }
            // exit the loop
    }   // return the board after the game has been played
        return board;
    }
}
