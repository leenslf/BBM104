public class Main {
    public static void main(String[] args) {
        String[] lines = ReadFromFile.readFileBoard("board.txt");
        String move = ReadFromFile.readFileMove("move.txt");
        int numMoves =  move.split("\\s+").length;
        int columns = ReadFromFile.numColumns(lines);
        int rows = ReadFromFile.numRows(lines);
        if (rows > 20 || columns > 20) {
            System.out.println("Incorrect dimensions");
        }if (numMoves > 30) {
            System.out.println("The input list can't contain more than 30 movement commands.");
        }else{
            System. out.println("Game board:");
            WriteToFile.writeUsingFileWriter("Game board:\n");
            for (String line : lines) {
                System. out.println(line);
                WriteToFile.writeUsingFileWriter(line+"\n");
            }
            System. out.println("\nYour movement is:");
            WriteToFile.writeUsingFileWriter("\nYour movement is:\n");
            System. out.println(move);
            WriteToFile.writeUsingFileWriter(move+"\n");
            String[][] board = InitializeGame.playGame(lines,move);
            System.out.println("\nYour output is:");
            WriteToFile.writeUsingFileWriter("\nYour output is:\n");
            for (String[] line : board) {
                for (String cell : line) {
                    System.out.print(cell + " ");
                    WriteToFile.writeUsingFileWriter(cell + " ");
                }
                System.out.println();
                WriteToFile.writeUsingFileWriter("\n");
            }
            InitializeGame myClass = new InitializeGame();
            int score = myClass.score;
            System.out.println("\nScore: " + score);
            WriteToFile.writeUsingFileWriter("\nScore:" + score);
        }
    }
}