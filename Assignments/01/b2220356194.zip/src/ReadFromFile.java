import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
public class ReadFromFile {
    public static String[] readFileBoard(String path) {
        try {
            int i = 0;
            int length = Files.readAllLines(Paths.get(path)).size();
            String[] results = new String[length];
            for (String line : Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }
            return results;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String readFileMove(String path) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            String line = String.join(System.lineSeparator(), lines);
            return line;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    public static int numColumns(String[] results) {
        int numColumns = 0;
        for (String line : results) {
            String[] substrings = line.split("\\s+");
            numColumns = substrings.length;
            break;
        }
        return numColumns;
    }
    public static int numRows(String[] results) {
        int numRows = 0;
        String[] lines = readFileBoard("board.txt");
        for (String line : lines) {
            numRows += 1 ;
        }
        return numRows;
    }
}
