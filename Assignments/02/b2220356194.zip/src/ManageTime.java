import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The ManageTime class is used to manage time-related operations and switch on devices at specified times.
 */
public class ManageTime {
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss");
    private static LocalDateTime time;

    /**
     * The constructor for ManageTime.
     */
    public ManageTime() {
        this.time = null;
    }

    /**
     * Sets the current time.
     *
     * @param time The time to set.
     * @throws Exception If the time is null.
     */
    public void setTime(LocalDateTime time) throws Exception {
        try {
            if (time != null) {
                this.time = time;
                List<String> entriesToRemove = new ArrayList<>();
                for (Map.Entry<String, LocalDateTime> entry : (CommandInterpreter.switchTimes).entrySet()) {
                    LocalDateTime dateTime = entry.getValue();
                    if (dateTime.isBefore(time)) { // check if the switch time is in the past
                        String deviceName = entry.getKey(); // get the device associated with the entry
                        SmartDeviceFactory.setSwitchTime(deviceName ,null); // set the switch time to null
                        entriesToRemove.add(entry.getKey()); // add the entry key to the list of entries to be removed
                    }
                }
                for (String key : entriesToRemove) {
                    (CommandInterpreter.switchTimes).remove(key);
                }
            } else {
                throw new Exception("Time cannot be null");
            }
        }  catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }
    }

    /**
     * Returns the current time in formatted string.
     * @return The formatted time string.
     */
    public static String getTimeFormatted() {
        return time.format(FORMATTER);
    }

    /**
     * Returns the current time.
     * @return The current time.
     */
    public static LocalDateTime getTime() {
        return time;
    }

    /**
     * Skips a number of minutes in the current time.
     * @param minutes The number of minutes to skip.
     */
    public void skipMinutes(int minutes) {
        this.time = time.plusMinutes(minutes);
    }
}
