import java.time.LocalDateTime;

/**
 * A class that represents a smart lamp with color functionality.
 * Extends the SmartLamp class.
 */
public class SmartLampWithColor extends SmartLamp{

    private int colorCode;
    private boolean colorMode;

    /**
     * Constructor for SmartLampWithColor class.
     * @param name the name of the smart lamp
     */
    public SmartLampWithColor(String name) {
        super(name);
        try{
            this.colorCode = 0;
            this.colorMode = false;
            if (smartDeviceNames.contains(name)) {
                throw new Exception("ERROR: There is already a smart device with the same name!");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }
        smartDeviceNames.add(name);
    }

    /**
     * Setter method for setting the color code
     * @param colorCode the color code to be set
     */
    public void setColorCode(int colorCode) {
        this.colorCode = colorCode;
        setColorMode(true); // lamp IS in color mode when color code is set
    }

    /**
     * Setter method for setting the color mode
     * @param colorMode the color mode to be set
     */
    public void setColorMode(boolean colorMode) {
        this.colorMode = colorMode;
    }

    /**
     * Getter method for getting the color mode
     * @return the current color mode
     */

    /**
     * Overridden method to set the kelvin value and reset the color mode
     * @param kelvin the kelvin value to be set
     * @throws Exception if the kelvin value is not within the range of 1700-6500
     */
    @Override
    public void setKelvin(int kelvin) throws Exception {
        super.setKelvin(kelvin);
        setColorMode(false); // lamp is NOT in color mode when kelvin is set
    }

    /**
     * Getter method for getting the color code
     * @return the current color code
     */
    public int getColorCode() {
        return colorCode;
    }

    /**
     * Returns a string representation of the SmartLampWithColor object
     * @return the string representation of the object
     */
    public String toString() {
        String status = isOn() ? "on" : "off";
        String switchTime = getSwitchTime() != null ? getSwitchTime().format(FORMATTER) : "null";
        if (colorMode) {
            return "Smart Color Lamp " + getName() + " is " + status + " and its  color value is " + getColorCode() + " with "
                    + getBrightness() + "% brightness, and its time to switch its status is " + switchTime + ".";
        } else {
            return "Smart Color Lamp " + getName() + " is " + status + " and its kelvin value is " + getKelvin() + "K  with "
                    + getBrightness() + "% brightness, and its time to switch its status is " + switchTime + ".";
        }
    }

    // Override methods from superclass
    @Override
    public void setBrightness(int brightness) throws Exception {
        super.setBrightness(brightness);
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }
    @Override
    public String getName(){
        return super.getName();
    }

    @Override
    public void setSwitchTime(LocalDateTime switchTime) throws Exception {
        super.setSwitchTime(switchTime);
    }

    @Override
    public LocalDateTime getSwitchTime() {
        return super.getSwitchTime();
    }

    @Override
    public void turnOn() {
        super.turnOn();
    }

    @Override
    public void turnOff() {
        super.turnOff();
    }
}