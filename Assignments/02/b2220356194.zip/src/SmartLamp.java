import java.time.LocalDateTime;

/**
 SmartLamp class represents a smart lamp device that extends SmartDevice.
 It provides functionality to control the Kelvin value and brightness of the lamp.
 */
public class SmartLamp extends SmartDevice {
    private int kelvin;
    private int brightness;

    /**
     Constructor for SmartLamp class.
     @param name The name of the smart lamp.
     */
    public SmartLamp(String name) {
        super(name); // Call superclass constructor
        try{
            if (smartDeviceNames.contains(name)) {
                throw new Exception("ERROR: There is already a smart device with the same name!");}
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }

        smartDeviceNames.add(name); // Add the smartLamp name to the HashSet
        this.kelvin = 4000;
        this.brightness = 100;
    }

    /**
     Setter method for kelvin field, also validates the value.
     @param kelvin The kelvin value to be set.
     */
    public void setKelvin(int kelvin) throws Exception {
        this.kelvin = kelvin;
    }



    /**
     Setter method for brightness field, also validates the value.
     @param brightness The brightness value to be set.
     @throws Exception If brightness value is not within the range of 0%-100%.
     */
    public void setBrightness(int brightness) throws Exception {
        this.brightness = brightness;
    }

    /**
     Getter method for kelvin field.
     @return The kelvin value of the lamp.
     */
    public int getKelvin() {
        return kelvin;
    }

    /**
     Getter method for brightness field.
     @return The brightness value of the lamp.
     */
    public int getBrightness() {
        return brightness;
    }

    /**
     Returns a string representation of the SmartLamp object.
     @return The string representation of the SmartLamp object.
     */
    public String toString() {
        String status = isOn() ? "on" : "off";
        String switchTime = getSwitchTime() != null ? getSwitchTime().format(FORMATTER) : "null";
        return "Smart Lamp "+getName()+" is "+status+" and its kelvin value is "+getKelvin()+"K  with "
                +getBrightness()+"% brightness, and its time to switch its status is "+switchTime+".";
    }

    // Override methods from superclass
    @Override
    public void setSwitchTime(LocalDateTime switchTime) throws Exception {
        super.setSwitchTime(switchTime);
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public String getName(){
        return super.getName();
    }


    @Override
    public LocalDateTime getSwitchTime() {
        return super.getSwitchTime();
    }

    @Override
    public void turnOn() {
        super.turnOn();
    }

    @Override
    public void turnOff() {
        super.turnOff();
    }

}
