import java.time.Duration;
import java.time.LocalDateTime;

/**
 The SmartCamera class represents a smart camera device that extends the SmartDevice class.
 It keeps track of the used storage in megabytes, and prevents duplicate names for smart cameras.
 */
class SmartCamera extends SmartDevice {
    private double usedStorage; // Stores the amount of storage used in megabytes
    private LocalDateTime onTime;
    private LocalDateTime offTime;
    private double mbPerMinute;

    /**
     Constructor for SmartCamera class.
     @param name The name of the SmartCamera device.
     @throws Exception if name does not start with "Camera" or if there is already a smart device with the same name.
     */
    public SmartCamera(String name) throws Exception {
        super(name);
        this.usedStorage = 0.0; // Initialize usedStorage to 0.0
        this.mbPerMinute =  0.0; // Initialize mbPerMinute to 0.0
        this.onTime = null;
        this.offTime = null;
        try{
            if (smartDeviceNames.contains(name)) {
                throw new Exception("ERROR: There is already a smart device with the same name!"); // Check for duplicate names
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }
        smartDeviceNames.add(name); // Add the name to the set of smartCameraNames
    }

    /**
     Getter method for getting the used storage.
     @return The amount of used storage in megabytes.
     */
    public double getUsedStorage() {
        return usedStorage;
    }

    /**
     Method to update the storage with the given value in megabytes per minute.
     @param mbPerMinute The value of megabytes to be updated.
     @throws Exception if the value of mbPerMinute is negative.
     */
    public void updateStorage(double mbPerMinute) {
        try{
            if (mbPerMinute > 0){
                this.mbPerMinute = mbPerMinute;
            } else {
                throw new Exception("ERROR: Megabyte value has to be a positive number!");} // Throw an exception for negative values
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }
    }

    /**
     * Method to calculate used storage with respect to time.
     */
    public void calUsedStorage(double mbPerMinute) {
        if (onTime != null && isOn() && offTime == null) {
            Duration timeDiff = Duration.between(onTime, ManageTime.getTime());
            long minutes = timeDiff.toMinutes();
            double usedStorage = mbPerMinute * minutes;
            this.usedStorage = Math.round(usedStorage * 100.0) / 100.0;

        } if (onTime != null && !isOn() && offTime != null) {
            Duration timeDiff = Duration.between(onTime, offTime);
            long minutes = timeDiff.toMinutes();
            double usedStorage = mbPerMinute * minutes;
            this.usedStorage = Math.round(usedStorage * 100.0) / 100.0;
        }
    }


    /**
     Returns a string displaying the current status of the device.
     @return A string with the current status of the device.
     */
    public String toString() {
        String status = isOn() ? "on" : "off";
        double storage = getUsedStorage();
        String switchTime = getSwitchTime() != null ? getSwitchTime().format(FORMATTER) : "null";
        return "Smart Camera " + getName() + " is " + status + " and used "+storage+
                " MB of storage so far (excluding current status), and its time to switch its status is "
                + switchTime + ".";
    }

    // Override methods from superclass
    @Override
    public void setName(String name){
        super.setName(name);
    }

    @Override
    public String getName(){
        return super.getName();
    }
    @Override
    public void setSwitchTime(LocalDateTime switchTime) throws Exception {
        super.setSwitchTime(switchTime);
    }

    @Override
    public LocalDateTime getSwitchTime() {
        return super.getSwitchTime();
    }

    @Override
    public void turnOn() {
        super.turnOn();
        this.onTime = ManageTime.getTime();
        calUsedStorage(mbPerMinute);
    }

    @Override
    public void turnOff() {
        super.turnOff();
        this.offTime = ManageTime.getTime();
        calUsedStorage(mbPerMinute);
    }

}
