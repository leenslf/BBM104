import java.time.Duration;
import java.time.LocalDateTime;

/**

 SmartPlug class represents a smart plug device that extends the SmartDevice class.

 It provides additional functionalities specific to a smart plug such as setting ampere, calculating watt,

 getting plug status, and overriding methods from the superclass.
 */
public class SmartPlug extends SmartDevice {
    private final double voltage;
    private double ampere;
    private double watt;
    private boolean plugOn;
    private LocalDateTime onTime;
    private Duration hours;
    private LocalDateTime offTime;

    /**

     Constructor for SmartPlug class.
     @param name the name of the smart plug device.
     */
    public SmartPlug(String name) {
        super(name); // Call superclass constructor
        this.voltage = 220;
        this.ampere = 0;
        this.watt = 0;
        this.plugOn = false;
        this.onTime = null;
        this.offTime = null;
        this.hours = Duration.ZERO;
        try {
            if (smartDeviceNames.contains(name)) {
                throw new Exception("ERROR: There is already a smart device with the same name!");
            }
            smartDeviceNames.add(name); // Add the smartPlugName to the HashSet
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }
    }
    /**

     Setter method for the ampere field. It also updates the plugOn and onTime fields.
     @param ampere the value to set for the ampere field.
     */
    public void setAmpere(Double ampere) {
        if (ampere > 0) {
            if (!plugOn) {
                // If plug is turning on, set onTime to current time
                plugOn = true;
                this.onTime = ManageTime.getTime();
            }
            this.ampere = ampere;
        } else if (ampere == 0) {
            if (plugOn) {
                // If plug is turning off, set offTime to current time
                plugOn = false;
                this.offTime = ManageTime.getTime();
            }
            calculateWatt();
        }
    }

    /**
     Calculates the watt consumed by the smart plug.
     */
    public void calculateWatt() {
        if (plugOn) {
            Duration timeDiff = Duration.between(this.onTime, ManageTime.getTime());
            this.hours = this.hours.plus(timeDiff);
        } else {
            Duration timeDiff = Duration.between(this.onTime, this.offTime);
            this.hours = this.hours.plus(timeDiff);
        }
        this.watt = (this.ampere * this.voltage * this.hours.toMillis()) / (1000 * 3600);
        this.watt = Math.round(this.watt * 100.0) / 100.0;
    }
     public double getWatt(){
        return watt;
     }

    /**
     Getter method that states whether the plug is plugged in or not.
     @return true if the plug is plugged in, false otherwise.
     */
    public boolean getPlugStatus() {
        return plugOn;
    }

    /**

     Returns a string representation of the SmartLamp object.
     @return The string representation of the SmartLamp object.
     */

    public String toString() {
        String plugStatus = isOn() ? "on" : "off";
        String calcWatt = String.valueOf(getWatt());
        String switchTime = getSwitchTime() != null ? getSwitchTime().format(FORMATTER) : "null";
        return "Smart Plug " + getName() + " is " + plugStatus + " and has consumed " + calcWatt
                + "W so far (excluding current device), and its time to switch its status is " + switchTime + ".";
    }

    // Override methods from superclass
    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public LocalDateTime getSwitchTime() {
        return super.getSwitchTime();
    }

    @Override
    public void turnOn() {
        super.turnOn();
    }

    @Override
    public void turnOff() {
        super.turnOff();
        if (onTime!=null){
        this.offTime= ManageTime.getTime();
        }
        if (onTime!=null && offTime!=null && ampere!=0){
            calculateWatt();
        }
    }
}
