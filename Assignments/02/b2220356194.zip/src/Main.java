public class Main {
    public static void main(String[] args){
        try {
            String[] file = ReadWriteText.readFile("input.txt");
            CommandInterpreter.interpretCommand(file);
        }catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }
    }
}
