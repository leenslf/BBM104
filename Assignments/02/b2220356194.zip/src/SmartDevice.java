import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.Set;

/**
 * SmartDevice class represents a smart device that can be controlled based on switch time.
 * It provides methods to set switch time, set name, get name, get switch time, get device status,
 * turn on the device, and turn off the device.
 * This is the superclass of SmartPlug, SmartCamera, SmartLamp, and SmartLampWithColor classes.
 */
class SmartDevice {

    /** The name of the smart device. */
    private String name;

    /** The switch time of the smart device. */
    private LocalDateTime switchTime;

    /** The status of the smart device (on/off). */
    private boolean isOn;

    /** The set of all existing smart device names. */
    protected static Set<String> smartDeviceNames= new HashSet<>();

    /** The date-time formatter used to format the switch time. */
    protected static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss");

    /**
     * Creates a new SmartDevice instance with the specified name.
     *
     * @param name the name of the smart device
     */
    public SmartDevice(String name) {
        this.name = name;
        this.switchTime = null;
        this.isOn = false;
    }

    /**
     * Sets the switch time of the smart device with the specified switch time.
     *
     * @param switchTime the switch time of the smart device
     * @throws DateTimeParseException if the specified switch time is not in the correct format
     * @throws Exception if the specified switch time is null
     */
    public void setSwitchTime(LocalDateTime switchTime) throws DateTimeParseException, Exception {
        try {
            this.switchTime = switchTime;
        } catch (DateTimeParseException e) {
            System.out.println("ERROR: Time format is not correct!");
            ReadWriteText.writer("ERROR: Time format is not correct!\n");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + '\n');
        }
    }

    /**
     * Sets the name of the smart device with the specified name.
     *
     * @param name the name of the smart device
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the name of the smart device.
     *
     * @return the name of the smart device
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the switch time of the smart device.
     *
     * @return the switch time of the smart device
     */
    public LocalDateTime getSwitchTime() {
        return switchTime;
    }

    /**
     * Returns the status of the smart device.
     *
     * @return true if the device is on, false otherwise
     */
    public boolean isOn() {
        return isOn;
    }

    /**
     * Turns on the smart device.
     */
    public void turnOn() {
        isOn = true;
    }

    /**
     * Turns off the smart device.
     */
    public void turnOff() {
        isOn = false;
    }
}
