import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;

/**

 The CommandInterpreter class interprets commands provided in an input file and performs corresponding

 actions based on the command type. It manages switch times of devices, sets initial time, sets time,

 sets switch time, skips minutes, adds devices, sets lamp properties, removes devices, and changes

 device names based on the input commands. The class uses the ManageTime and SmartDeviceFactory

 classes to perform these actions.
 */
public class CommandInterpreter {

    /**

     initialized represents whether the initial time is set or not.
     */
    private static int initialized = 0;
    /**

     manageTime is an instance of the ManageTime class that manages time-related actions.
     */
    private static ManageTime manageTime;
    /**

     switchTimes is a HashMap containing device names and their corresponding switch times.
     */
    protected static HashMap<String, LocalDateTime> switchTimes = new HashMap<>();
    /**

     This method interprets the commands in the given input file.

     @param file An array of commands.
     */
    public static void interpretCommand(String[] file) {
        try {
            for (String input : file) {
                String[] tokens = input.split("\\s+");
                String command = tokens[0];
                if (command.equals("")){ continue; }
                System.out.println("COMMAND: " + String.join(" ", tokens));
                ReadWriteText.writer("COMMAND: " + String.join(" ", tokens) + '\n');
                if (initialized == 0 && !command.equals("SetInitialTime")) {
                    throw new Exception("ERROR: First command must be set initial time! Program is going to terminate!");
                }

                try {
                    switch (command) {
                        case "SetInitialTime" :
                            try {
                                if (initialized == 0) {
                                    manageTime = new ManageTime();
                                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss");
                                    LocalDateTime dateTime = LocalDateTime.parse(tokens[1], formatter);
                                    manageTime.setTime(dateTime);
                                    initialized += 1;
                                    System.out.println("SUCCESS: Time has been set to " + tokens[1] + "!");
                                    ReadWriteText.writer("SUCCESS: Time has been set to " + tokens[1] + "!\n");
                                } else {
                                    throw new Exception("ERROR: Erroneous command!");
                                }
                            } catch (DateTimeParseException e) {
                                System.out.println("ERROR: Format of the initial date is wrong! Program is going to terminate!");
                                ReadWriteText.writer("ERROR: Format of the initial date is wrong! Program is going to terminate!\n");
                                System.exit(0);
                            } catch (ArrayIndexOutOfBoundsException e) {
                                System.out.println("ERROR: First command must be set initial time! Program is going to terminate!");
                                ReadWriteText.writer("ERROR: First command must be set initial time! Program is going to terminate!\n");
                                System.exit(0);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                                ReadWriteText.writer(e.getMessage() + "\n");
                            }
                            break;

                        case "SetTime" :
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss");
                            try {
                                LocalDateTime dateTime = LocalDateTime.parse(tokens[1], formatter);
                                manageTime.setTime(dateTime);
                                if (!(tokens.length > 1)) {
                                    throw new Exception("ERROR: Missing argument for SetTime command!");
                                }
                            } catch (DateTimeParseException e) {
                                System.out.println("ERROR: Time format is not correct!");
                                ReadWriteText.writer("ERROR: Time format is not correct!\n");
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                                ReadWriteText.writer(e.getMessage() + '\n');
                            }
                            break;

                        case "SetSwitchTime" :
                            try {
                                DateTimeFormatter formatter0 = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss");
                                if (tokens.length > 2) {
                                    String deviceName = tokens[1];
                                    LocalDateTime switchTime = LocalDateTime.parse(tokens[2], formatter0);
                                    switchTimes.put(deviceName, switchTime);
                                    SmartDeviceFactory.setSwitchTime(deviceName, switchTime);
                                } else {
                                    throw new Exception("Missing argument(s) for SetSwitchTime command!");
                                }
                            } catch (Exception e) {
                                System.out.println("ERROR: " + e.getMessage());
                                ReadWriteText.writer("ERROR: " + e.getMessage() + '\n');
                            }
                            break;

                        case "SkipMinutes":
                            try {
                                if (tokens.length < 2) {
                                    throw new Exception("ERROR: Missing argument for SkipMinutes command!");
                                }
                                int minutes = 0;
                                try {
                                    minutes = Integer.parseInt(tokens[1]);
                                } catch (NumberFormatException ex) {
                                    throw new Exception("ERROR: Invalid argument for SkipMinutes command!");
                                }
                                if (minutes < 0) {
                                    throw new Exception("ERROR: Time cannot be reversed!");
                                } else if (minutes == 0) {
                                    throw new Exception("ERROR: There is nothing to skip!");
                                }
                                manageTime.skipMinutes(minutes);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                                ReadWriteText.writer(e.getMessage() + "\n");
                            }
                            break;

                        case "Add" :
                            SmartDeviceFactory.createDevice(tokens[1], tokens);
                            break;

                        case "SetKelvin":
                        case "SetBrightness":
                        case "SetWhite":
                            SmartDeviceFactory.setLamp(tokens, tokens[0], tokens[1]);
                            break;

                        case "SetColorCode":
                        case "SetColor":
                            SmartDeviceFactory.setColorLamp(tokens, tokens[0], tokens[1]);
                            break;

                        case "Remove" :
                            SmartDeviceFactory.removeDevice(tokens[1]);
                            break;

                        case "ChangeName" :
                            String originalName = tokens[1];
                            try {
                                if (tokens.length < 3) {
                                    throw new Exception("ERROR: Missing argument(s) for ChangeName command!");
                                } else {
                                    String newName = tokens[2];
                                    if (originalName.equals(newName)) {
                                        throw new Exception("ERROR: Both of the names are the same, nothing changed!");
                                    }
                                    try {
                                        SmartDeviceFactory.changeName(originalName, newName);
                                    } catch (Exception e) {
                                        System.out.println(e.getMessage());
                                        ReadWriteText.writer(e.getMessage() + '\n');
                                    }
                                }
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                                ReadWriteText.writer(e.getMessage() + '\n');

                            }
                            break;

                        case "Switch" :
                            SmartDeviceFactory.switchOnOff(tokens[1], tokens[2]);
                            break;

                        case "PlugIn" :
                            SmartDeviceFactory.plugIn(tokens[1], tokens[2]);
                            break;

                        case "PlugOut" :
                            SmartDeviceFactory.plugOut(tokens[1]);
                            break;

                        case "Nop" :
                            try {
                                Map.Entry<String, LocalDateTime> firstSwitch = SmartDeviceFactory.findSoonestDate(switchTimes);
                                if (firstSwitch != null) {
                                    manageTime.setTime(firstSwitch.getValue());
                                    switchTimes.remove(firstSwitch.getKey());
                                    for (Map.Entry<String, LocalDateTime> entry : switchTimes.entrySet()) {
                                        String deviceName = entry.getKey();
                                        LocalDateTime switchTime = entry.getValue();
                                        LocalDateTime time = ManageTime.getTime();
                                        if (time.equals(switchTime)) {
                                            SmartDevice device = SmartDeviceFactory.findDeviceByName(deviceName);
                                            device.turnOn();
                                            device.setSwitchTime(null);
                                        }
                                    }
                                } else {
                                    throw new Exception("ERROR: There is nothing to switch!");
                                }
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                                System.out.println("Current time: " + ManageTime.getTimeFormatted()); // Add this line to check the format of the time string
                                ReadWriteText.writer(e.getMessage() + '\n');
                            }
                            break;

                        case "ZReport" :
                            System.out.println("Time is: " + ManageTime.getTimeFormatted());
                            ReadWriteText.writer("Time is: " + ManageTime.getTimeFormatted() + '\n');
                            for (SmartDevice smartDevice : SmartDeviceFactory.smartDevices.values()) {
                                if (smartDevice instanceof SmartPlug)  {
                                    ReadWriteText.writer(smartDevice.toString() + "\n");
                                } else if (smartDevice instanceof SmartCamera) {
                                    ReadWriteText.writer(smartDevice.toString() + "\n");
                                } else if (smartDevice instanceof SmartLampWithColor) {
                                    ReadWriteText.writer(smartDevice.toString() + "\n");
                                } else if (smartDevice instanceof SmartLamp) {
                                    ReadWriteText.writer(smartDevice.toString() + "\n");
                                }
                            }
                            break;

                        default :
                            throw new Exception("ERROR: Erroneous command!");

                    }

                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    ReadWriteText.writer(e.getMessage() + "\n");
                }

            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + "\n");
            System.exit(0);
        }
    }
}

