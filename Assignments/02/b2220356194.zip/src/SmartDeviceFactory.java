import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;

/**
 The SmartDeviceFactory class is a factory class that creates and manages different types of smart devices,
 such as SmartPlugs, SmartCameras, SmartLamps, and SmartColorLamps. It provides methods for:
 creating devices with specified features
 storing the created devices in a HashMap for future reference
 finding devices by name
 setting lamps with specific features
 removing a device
 setting switch time
 finding the first switch time
 Changing the name of a device
 switching a device on or off
 plugging in a smart plug
 plugging out a smart plug
 */
public class SmartDeviceFactory  {
    /*
    smartDevices <DeviceName, SmartDevice object> stores all the devices added
    */
    protected static HashMap<String, SmartDevice> smartDevices = new HashMap<>();

    /**
     Find a smart device by its name
     @param deviceName the name of the smart device
     @return the SmartDevice object with the given name
     */
    public static SmartDevice findDeviceByName(String deviceName) {
        try {
            if (!smartDevices.containsKey(deviceName)) {
                throw new Exception("ERROR: There is no such device!");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + '\n');
        }
        return smartDevices.get(deviceName);
    }

    /**

     Create a smart device with the specified features and store it in the smartDevices map
     @param deviceType the type of the device to create
     @param tokens an array of tokens containing the device's features
     */
    public static void createDevice(String deviceType, String[] tokens) {
        try {
            // Check if a device with the same name already exists
            SmartDevice deviceName = smartDevices.get(tokens[2]);
            if (deviceName != null) {
                throw new Exception("ERROR: There is already a smart device with the same name!");
            }

            // Create a new device based on its type
            switch (deviceType) {
                case "SmartPlug" :
                    String smartPlugName = tokens[2];
                    String smartPlugInStat = tokens.length >= 4 ? tokens[3] : null;
                    String ampere = tokens.length >= 5 ? tokens[4] : null;
                    double ampereValue = 0.0;
                    if (ampere != null && !ampere.isEmpty()) {
                        try {
                            ampereValue = Double.parseDouble(ampere);
                            if (ampereValue <= 0.0) {
                                throw new Exception("ERROR: Ampere value must be a positive number!");
                            }
                        } catch (NumberFormatException e) {
                            throw new Exception("ERROR: Invalid ampere value!");
                        }
                    }

                    SmartPlug smartPlug = new SmartPlug(smartPlugName);

                    // Turn on or off the smart plug
                    if (smartPlugInStat != null && smartPlugInStat.equals("Off")) {
                        smartPlug.turnOff();
                    } else {
                        smartPlug.turnOn();
                    }
                    // Set the ampere value of the smart plug, if provided
                    if (ampereValue > 0.0) {
                        smartPlug.setAmpere(ampereValue);
                    }
                    // Add the smart plug to the list of smart devices
                    smartDevices.put(smartPlugName, smartPlug);
                    break;

                case "SmartCamera" :
                    String smartCameraName = tokens[2];
                    double mbPerMinute = tokens.length >= 4 ? Double.parseDouble(tokens[3]) : 0.0;
                    String smartCameraInStat = tokens.length >= 5 ? tokens[4] : null;
                    if (mbPerMinute <= 0.0) {
                        throw new Exception("ERROR: Ampere value must be a positive number!");
                    }
                    SmartCamera smartCamera = new SmartCamera(smartCameraName);

                    // Turn on or off the smart camera
                    if (smartCameraInStat != null && smartCameraInStat.equals("Off")) {
                        smartCamera.turnOff();
                    } if (smartCameraInStat != null && smartCameraInStat.equals("On"))  {
                        smartCamera.turnOn();
                    }
                    // Set the storage of the smart camera, if provided
                    if (mbPerMinute != 0.0) {
                        try {
                            smartCamera.updateStorage(mbPerMinute);
                        } catch (NumberFormatException e) {
                            throw new Exception("ERROR: Invalid megabyte value!");
                        }
                    }
                    // Add the smart camera to the list of smart devices
                    smartDevices.put(smartCameraName, smartCamera);
                    break;

                case "SmartLamp" :
                    String smartLampName = tokens[2];
                    String smartLampInStat = tokens.length >= 4 ? tokens[3] : null;
                    String kelvin = tokens.length >= 5 ? tokens[4] : null;
                    String brightness = tokens.length >= 6 ? tokens[5] : null;
                    SmartLamp smartLamp = new SmartLamp(smartLampName);

                    if (smartLampInStat != null && smartLampInStat.equals("Off")) {
                        smartLamp.turnOff();
                    }
                    if (smartLampInStat != null && smartLampInStat.equals("On")) {
                        smartLamp.turnOn();
                    }
                    if (kelvin!=null){
                        int kelvinVal = Integer.parseInt(kelvin);
                        if (kelvinVal >= 2000 && kelvinVal <= 6500) {
                            smartLamp.setKelvin(kelvinVal);
                        } else { throw new Exception("ERROR: Kelvin value must be in the range of 2000K-6500K!");}
                    }
                    if (brightness!=null){
                        int brightnessVal = Integer.parseInt(kelvin);
                        if (brightnessVal >= 0 || brightnessVal <= 100) {
                            smartLamp.setBrightness(brightnessVal);
                        } else {throw new Exception("ERROR: Brightness must be in the range of 0%-100%!");}
                    }
                    smartDevices.put(smartLampName, smartLamp);
                    break;

                case "SmartColorLamp" :
                    String smartColorLampName = tokens[2];
                    String smartColorLampInStat = tokens.length >= 4 ? tokens[3] : null;
                    String kelvinOrColorCode = tokens.length >= 5 ? tokens[4] : null;
                    String brightnessC = tokens.length >= 6 ? tokens[5] : null;

                    SmartLampWithColor smartLampWithColor = new SmartLampWithColor(smartColorLampName);

                    if (smartColorLampInStat != null && smartColorLampInStat.equals("Off")) {
                        smartLampWithColor.turnOff();
                    }
                    if (smartColorLampInStat != null && smartColorLampInStat.equals("On")) {
                        smartLampWithColor.turnOn();
                    }
                    if (kelvinOrColorCode != null) {
                        if (kelvinOrColorCode.startsWith("0x")) { // Check if it's a color code (color code is hexadecimal)
                            String hexDigits = kelvinOrColorCode.substring(2); // Remove the "0x" prefix
                            if (isValidHexadecimal(hexDigits)) { // Check if the string only contains valid hexadecimal digits
                                int colorCode = Integer.parseInt(hexDigits, 16);
                                if (colorCode >= 0x000000 && colorCode <= 0xFFFFFF) { // Check if the color code is within the valid range
                                    smartLampWithColor.setColorCode(colorCode);
                                } else {
                                    throw new Exception("ERROR: Color code must be within the range [0x000000, 0xFFFFFF]!");
                                }
                            } else {
                                throw new Exception("ERROR: Invalid hexadecimal color code!");
                            }
                        } else { // Assume it's a kelvin value
                            smartLampWithColor.setKelvin(Integer.parseInt(kelvinOrColorCode));
                        }
                    }
                    if (brightnessC != null) {
                        smartLampWithColor.setBrightness(Integer.parseInt(brightnessC));
                    }

                    smartDevices.put(smartColorLampName, smartLampWithColor);
                    break;

                default :
                    throw new Exception("ERROR: Invalid device type!");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage()+'\n');
        }
    }

    /**
     Set the specified lamp with the given features
     @param tokens an array of tokens containing the lamp's features
     @param setType the type of the lamp to set
     @param lampName the name of the lamp to set
     */
    public static void setLamp(String[] tokens, String setType, String lampName) {
        try {
            if (!lampName.startsWith("Lamp") && !lampName.startsWith("CLamp")) {
                throw new Exception("ERROR: This device is not a smart lamp!");
            }

            SmartDevice device = findDeviceByName(lampName);

            if (device instanceof SmartLamp) {
                SmartLamp lamp = (SmartLamp) device;

                switch (setType) {
                    case "SetKelvin" :
                        String kelvin = tokens[2];
                        lamp.setKelvin(Integer.parseInt(kelvin));
                        break;
                    case "SetBrightness" :
                        String brightness = tokens[2];
                        lamp.setBrightness(Integer.parseInt(brightness));
                        break;
                    case "SetWhite" :
                        String kelvin0 = tokens[2];
                        String brightness0 = tokens[3];
                        lamp.setKelvin(Integer.parseInt(kelvin0));
                        lamp.setBrightness(Integer.parseInt(brightness0));
                        break;
                    default :
                        throw new Exception("ERROR: Invalid set type for SmartLamp!");
                }
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + '\n');
        }
    }

    /**
     Set the specified color lamp with the given features
     @param tokens an array of tokens containing the lamp's features
     @param setType the type of the lamp to set
     @param lampName the name of the lamp to set
     */
    public static void setColorLamp(String[] tokens, String setType, String lampName) {
        try {
            if (!lampName.startsWith("CL")) {
                throw new Exception("ERROR: This device is not a smart color lamp!");
            }

            SmartDevice device = findDeviceByName(lampName);
            if (!(device instanceof SmartLampWithColor)) {
                throw new Exception("ERROR: This device is not a smart color lamp!");
            }
            SmartLampWithColor lamp = (SmartLampWithColor) device;

            switch (setType) {
                case "SetColorCode" :
                    String colorCode = tokens[2];
                    if (isValidHexadecimal(colorCode)) {
                        lamp.setColorCode(Integer.decode(colorCode));
                    } else {
                        throw new Exception("ERROR: Invalid hexadecimal color code!");
                    }
                    break;
                case "SetColor" :
                    String colorCode0 = tokens[2];
                    String brightness = tokens[3];
                    if (isValidHexadecimal(colorCode0)) {
                        lamp.setColorCode(Integer.decode(colorCode0));
                        lamp.setBrightness(Integer.parseInt(brightness));
                    } else {
                        throw new Exception("ERROR: Invalid hexadecimal color code!");
                    }
                    break;
                default :
                    throw new Exception("ERROR: Invalid setType value!");
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + '\n');
        }
    }

    /**
     Check if a given input is a valid hexadecimal string
     @param input the string to check
     @return true if the input is a valid hexadecimal string, false otherwise
     */
    private static boolean isValidHexadecimal(String input) {
        String hexPattern = "[0-9A-Fa-f]+";
        return input.matches(hexPattern);
    }

    /**
     Removes the device with the specified name from the list of smart devices, turns off the device and prints information about it.
     If the device is a SmartPlug, the ampere value and time to switch its status are printed.
     If the device is a SmartCamera, the used storage per minute and time to switch its status are printed.
     If the device is a SmartLamp, the kelvin value, brightness and time to switch its status are printed.
     If the device is a SmartLampWithColor, the kelvin value and brightness are printed if the device is in kelvin mode,
     otherwise, the color value and brightness are printed, along with the time to switch its status.
     If no device with the specified name is found in the list of smart devices, an Exception is thrown.
     @param deviceName the name of the device to be removed
     */
    public static void removeDevice(String deviceName) {
        SmartDevice device = findDeviceByName(deviceName);
        if (device != null) {
            System.out.println("SUCCESS: Information about removed smart device is as follows:");
            ReadWriteText.writer("SUCCESS: Information about removed smart device is as follows:\n");
            if (deviceName.startsWith("Plug")) {
                if (device instanceof SmartPlug) {
                    SmartPlug plug = (SmartPlug) device;
                    plug.turnOff();
                    System.out.printf("Smart Plug %s is off and and consumed %s W so far, and its time to switch its status is %s.%n",
                            deviceName, plug.getWatt(), plug.getSwitchTime());
                    ReadWriteText.writer(String.format("Smart Plug %s is off and consumed %s W so far, and its time to switch its status is %s.%n",
                            deviceName, plug.getWatt(), plug.getSwitchTime()));
                }
            } else if (deviceName.startsWith("Camera")) {
                if (device instanceof SmartCamera) {
                    SmartCamera camera = (SmartCamera) device;
                    camera.turnOff();
                    System.out.printf("Smart Camera %s is off and its used storage is %s megabytes per minute and its time to switch its status is %s.%n",
                            deviceName, camera.getUsedStorage(), camera.getSwitchTime());
                    ReadWriteText.writer(String.format("Smart Camera %s is off and its used storage is %s megabytes per minute and its time to switch its status is %s.%n",
                            deviceName, camera.getUsedStorage(), camera.getSwitchTime()));
                }
            } else if (deviceName.startsWith("Lamp")) {
                if (device instanceof SmartLamp) {
                    SmartLamp lamp = (SmartLamp) device;
                    lamp.turnOff();
                    System.out.printf("Smart Lamp %s is off its kelvin value is %s K with %s%% brightness and its time to switch its status is %s.%n",
                            deviceName, lamp.getKelvin(), lamp.getBrightness(), lamp.getSwitchTime());
                    ReadWriteText.writer(String.format("Smart Lamp %s is off its kelvin value is %s K with %s%% brightness and its time to switch its status is %s.%n",
                            deviceName, lamp.getKelvin(), lamp.getBrightness(), lamp.getSwitchTime()));
                } else if (device instanceof SmartLampWithColor) {
                    SmartLampWithColor clamp = (SmartLampWithColor) device;
                    clamp.turnOff();
                    if (clamp instanceof SmartLampWithColor) { // check if it's a color lamp
                        System.out.printf("Smart Color Lamp %s is off its color value is %s with %s%% brightness and its time to switch its status is %s.%n",
                                deviceName, clamp.getColorCode(), clamp.getBrightness(), clamp.getSwitchTime());
                        ReadWriteText.writer(String.format("Smart Color Lamp %s is off its color value is %s with %s%% brightness and its time to switch its status is %s.%n",
                                deviceName, clamp.getColorCode(), clamp.getBrightness(), clamp.getSwitchTime()));
                    } else {
                        System.out.printf("Smart Lamp %s is off its kelvin value is %s K with %s%% brightness and its time to switch its status is %s.%n",
                                deviceName, clamp.getKelvin(), clamp.getBrightness(), clamp.getSwitchTime());
                        ReadWriteText.writer(String.format("Smart Lamp %s is off its kelvin value is %s K with %s%% brightness and its time to switch its status is %s.%n",
                                deviceName, clamp.getKelvin(), clamp.getBrightness(), clamp.getSwitchTime()));
                    }

                }

            }
            smartDevices.remove(deviceName);
        }
    }

    /**
     Sets the switch time of a device with the specified deviceName to the specified switchTime.
     Throws an Exception if the device with the specified deviceName is not found in the HashMap.
     @param deviceName the name of the device to set switch time for
     @param switchTime the switch time to set for the device
     */
    public static void setSwitchTime(String deviceName, LocalDateTime switchTime) throws Exception{
        SmartDevice device = findDeviceByName(deviceName);
        assert device != null;
        Objects.requireNonNull(device).setSwitchTime(switchTime);
    }

    /**
     Returns an Entry object representing the key-value pair with the soonest LocalDateTime value from the given Map.
     @param switchTime a Map object with String keys and LocalDateTime values
     @return an Entry object representing the key-value pair with the soonest LocalDateTime value from the given Map, or null if the Map is null or empty
     */
    public static Entry<String, LocalDateTime> findSoonestDate(Map<String, LocalDateTime> switchTime) {
        if (switchTime == null || switchTime.isEmpty()) {
            return null;
        }

        Entry<String, LocalDateTime> entryWithSoonestDate = null;
        LocalDateTime currentTime = ManageTime.getTime();

        for (Entry<String, LocalDateTime> entry : switchTime.entrySet()) {
            LocalDateTime dateTime = entry.getValue();
            if (dateTime.isAfter(currentTime)) {
                if (entryWithSoonestDate == null || dateTime.isBefore(entryWithSoonestDate.getValue())) {
                    entryWithSoonestDate = entry;
                }
            }
        }
        return entryWithSoonestDate;
    }

    /**
     Changes the name of a SmartDevice object with the given original name to the new name provided.
     @param originalName a String representing the original name of the SmartDevice object to be renamed
     @param newName a String representing the new name to be assigned to the SmartDevice object
    */
    public static void changeName(String originalName, String newName) throws Exception {
        SmartDevice originalDevice = findDeviceByName(originalName);
        SmartDevice newDevice = smartDevices.get(newName);
        if (newDevice != null) {
            throw new Exception("ERROR: There is already a smart device with the same name!");
        } else if (originalDevice != null) {
            originalDevice.setName(newName);
            smartDevices.remove(originalName);
            smartDevices.put(newName, originalDevice);
            // Moved the success message inside the try block
            System.out.println("SUCCESS: Device name has been changed from " + originalName + " to " + newName + "!");
            ReadWriteText.writer("SUCCESS: Device name has been changed from " + originalName + " to " + newName + "!\n");
        }
    }

    /**
     Turns a SmartDevice object with the given name on or off, depending on the OnOff parameter.
     @param deviceName a String representing the name of the SmartDevice object to be switched on or off
     @param OnOff a String representing whether the device should be switched "On" or "Off"
     */
    public static void switchOnOff(String deviceName, String OnOff) {
        try {
            SmartDevice device = findDeviceByName(deviceName);
            if (device!=null){
                if (OnOff.equals("On")) {
                    if (device.isOn()) {
                        throw new Exception("This device is already switched on!");
                    }
                    device.turnOn();
                }
                if (OnOff.equals("Off")) {
                    if (!device.isOn()) {
                        throw new Exception("This device is already switched off!");
                    }
                    device.turnOff();
                }
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + '\n');
        }
    }

    /**
     Attempts to plug a device into a SmartPlug object with the given name and ampere value.
     @param plugName a String representing the name of the SmartPlug object to be used
     @param ampere a String representing the ampere value of the device to be plugged in
     */
    public static void plugIn(String plugName, String ampere) {
        try {
            double ampereValue = Double.parseDouble(ampere);
            if (ampereValue < 0) {
                throw new Exception("Ampere value must be a positive number!");
            }
            if (plugName.startsWith("Lamp")||plugName.startsWith("CLamp")||plugName.startsWith("Camera")) {
                throw new Exception("ERROR: This device is not a smart plug!");
            }
            SmartDevice device = findDeviceByName(plugName);
            if (device instanceof SmartPlug) {
                SmartPlug plug = (SmartPlug) device;
                if (plug.getPlugStatus()) {
                    throw new Exception("There is already an item plugged in to that plug!");
                }
                plug.setAmpere(ampereValue);
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + '\n');
        }
    }

    /**
     Attempts to unplug the device from the SmartPlug object with the given name.
     @param plugName a String representing the name of the SmartPlug object to be used
     @throws Exception if the SmartPlug object is not found or if the device is not a SmartPlug object or if the SmartPlug object
     has no device to unplug
     */
    public static void plugOut(String plugName) {
        try {
            SmartDevice device = findDeviceByName(plugName);
            if (device instanceof SmartPlug) {
                SmartPlug plug = (SmartPlug) device; // downcast to subclass device
                if (!plug.getPlugStatus()) {
                    throw new Exception("ERROR: This plug has no item to plug out from that plug!");
                }
                plug.setAmpere((double) 0); // setting the ampere to 0 unplugs the device
            } else {
                throw new Exception("ERROR: This device is not a smart plug!");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            ReadWriteText.writer(e.getMessage() + '\n');
        }
    }

}