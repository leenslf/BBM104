import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ReadWriteText {
    public static String[] readFile(String path) {
        try {
            int i = 0;
            int length = Files.readAllLines(Paths.get(path)).size();
            String[] commands = new String[length];
            for (String line : Files.readAllLines(Paths.get(path))) {
                commands[i++] = line;
            }
            return commands;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void writer(String data) {
        File file = new File("output.txt");
        FileWriter fr = null;
        try {
            fr = new FileWriter(file, true); // set second argument to true to append to file
            fr.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //close resources
            try {
                assert fr != null;
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
