public class BlueDuck extends Duck {
    public BlueDuck() {
        super(2); // Pass the duck color number to the superclass constructor
    }
}