import javafx.animation.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.transform.Scale;
import javafx.util.Duration;
import java.util.HashMap;
import java.util.Map;


public class Duck extends DuckHuntGame {
    private static final double DUCK_WIDTH = 18 * getScale();
    private static final double DUCK_HEIGHT = 18 * getScale();
    private static Image duckShot;
    private static Image duckFall;
    private static Image duckDiagonal1;
    private static Image duckDiagonal2;
    private static Image duckDiagonal3;
    private static Image duckStraight1;
    private static Image duckStraight2;
    private static Image duckStraight3;
    Scale flipHorizontal = new Scale(-1, 1);
    private boolean isFlipped;
    boolean isReturning;
    boolean straightOrPentagon;
    boolean isShot;
    private TranslateTransition flyL2RTrTransition;
    PathTransition pathTransition;
    ImageView duckView;
    private Timeline wingFlappingTimeline;

    /**

     Creates a new instance of the Duck class with the specified duck color number.

     @param duckColorNum The color number of the duck.
     */
    public Duck(int duckColorNum) {
        super(scale, volume, primaryStage, WINDOW_WIDTH, WINDOW_HEIGHT);

        Map<Integer, String> colorMap = new HashMap<>();
        colorMap.put(1, "black");
        colorMap.put(2, "blue");
        colorMap.put(3, "red");

        String duckColor = colorMap.get(duckColorNum);
        if (duckColor != null) {
            duckDiagonal1 = loadImage("assets/duck_" + duckColor + "/1.png");
            duckDiagonal2 = loadImage("assets/duck_" + duckColor + "/2.png");
            duckDiagonal3 = loadImage("assets/duck_" + duckColor + "/3.png");
            duckStraight1 = loadImage("assets/duck_" + duckColor + "/4.png");
            duckStraight2 = loadImage("assets/duck_" + duckColor + "/5.png");
            duckStraight3 = loadImage("assets/duck_" + duckColor + "/6.png");
            duckShot = loadImage("assets/duck_" + duckColor + "/7.png");
            duckFall = loadImage("assets/duck_" + duckColor + "/8.png");
        }
    }

    /**

     Animates the flying of a duck from left to right across the screen.

     @param rootPane The root pane to which the duck view will be added.

     @param reverseDirection Flag indicating whether the duck should fly in reverse direction (from right to left).
     */
    public void flyL2R(Pane rootPane, boolean reverseDirection) {
        straightOrPentagon = true;

        // Create a timeline for the animation
        Duration displayDuration = Duration.millis(500);

        // Create the duck view and set its properties
        duckView = new ImageView();
        duckView.setFitWidth(DUCK_WIDTH);
        duckView.setFitHeight(DUCK_HEIGHT);

        // Create the wing flapping timeline with three keyframes
        wingFlappingTimeline = new Timeline(
                new KeyFrame(Duration.ZERO, event -> duckView.setImage(duckStraight1)),
                new KeyFrame(displayDuration, event -> duckView.setImage(duckStraight2)),
                new KeyFrame(displayDuration.multiply(2), event -> duckView.setImage(duckStraight3))
        );

        // Set up the TranslateTransition for flying from left to right or in reverse direction
        flyL2RTrTransition = new TranslateTransition(Duration.millis(4000), duckView);

        if (!reverseDirection) {
            // Set initial position at the right edge of the screen
            duckView.setScaleX(-1);
            flyL2RTrTransition.setFromX(WINDOW_WIDTH - DUCK_WIDTH);
            flyL2RTrTransition.setToX(0);
        } else {
            // Set initial position at the left edge of the screen
            flyL2RTrTransition.setFromX(0);
            // Set final position at the right edge of the screen
            flyL2RTrTransition.setToX(WINDOW_WIDTH - DUCK_WIDTH);
        }

        // Set initial and final vertical positions
        flyL2RTrTransition.setFromY((WINDOW_HEIGHT - DUCK_HEIGHT) / 4);
        flyL2RTrTransition.setToY((WINDOW_HEIGHT - DUCK_HEIGHT) / 4);

        // Set the wing flapping timeline to repeat indefinitely
        wingFlappingTimeline.setCycleCount(Timeline.INDEFINITE);
        wingFlappingTimeline.play(); // Start playing the timeline

        // Flip transformation variables
        isFlipped = false; // Track if the image is currently flipped or not
        isReturning = false; // Track if the duck is returning to its original position

        // Link the timeline animation to the TranslateTransition
        flyL2RTrTransition.setAutoReverse(true);
        flyL2RTrTransition.setCycleCount(TranslateTransition.INDEFINITE);
        flyL2RTrTransition.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
            // Check if the object has reached the end position
            if (newValue.equals(flyL2RTrTransition.getCycleDuration())) {
                if (isFlipped) {
                    duckView.getTransforms().remove(flipHorizontal); // Remove the flip transformation
                    isFlipped = false;
                } else {
                    duckView.getTransforms().add(flipHorizontal); // Add the flip transformation
                    isFlipped = true;
                }
                isReturning = true; // Set flag to indicate the duck is returning
            } else if (newValue.equals(Duration.ZERO)) {
                if (isFlipped) {
                    duckView.getTransforms().remove(flipHorizontal); // Remove the flip transformation
                    isFlipped = false;
                } else {
                    duckView.getTransforms().add(flipHorizontal); // Add the flip transformation
                    isFlipped = true;
                }
                isReturning = false; // Reset the flag when the duck starts moving from the beginning
            }
            // Check if the duck is back to its original starting point
            if (isReturning && newValue.equals(Duration.ZERO)) {
                duckView.getTransforms().remove(flipHorizontal); // Remove the flip transformation
                isFlipped = false;
            }
        });

        flyL2RTrTransition.play();

         // Add the visible object to the root pane
        rootPane.getChildren().add(duckView);
    }


    public void flyPentagon(Pane rootPane ,boolean reverseDirection)  {
        straightOrPentagon = false;
        Duration displayDuration = Duration.millis(500);
        duckView = new ImageView();
        duckView.setFitWidth(DUCK_WIDTH);
        duckView.setFitHeight(DUCK_HEIGHT);
        wingFlappingTimeline = new Timeline(
                new KeyFrame(Duration.ZERO, event -> duckView.setImage(duckDiagonal1)),
                new KeyFrame(displayDuration, event -> duckView.setImage(duckDiagonal2)),
                new KeyFrame(displayDuration.multiply(2), event -> duckView.setImage(duckDiagonal3))
        );
        wingFlappingTimeline.setCycleCount(Timeline.INDEFINITE);
        wingFlappingTimeline.play();

        Scale flipHorizontal = new Scale(-1, 1);
        Scale flipVertical = new Scale(1, -1);
        Scale flipVerHor = new Scale(-1, -1);
        Path diamondPath = new Path();
        if (!reverseDirection){
            duckView.setScaleX(-1);
            diamondPath.getElements().addAll(
                    new MoveTo(WINDOW_WIDTH, WINDOW_HEIGHT / 4.0),
                    new LineTo(WINDOW_WIDTH / 2.0, 0),
                    new LineTo(0, WINDOW_HEIGHT / 4.0),
                    new LineTo(WINDOW_WIDTH / 2.0, WINDOW_HEIGHT / 1.3),
                    new ClosePath()
            );
        } else{
            diamondPath.getElements().addAll(
                    new MoveTo(0, WINDOW_HEIGHT / 4.0),
                    new LineTo(WINDOW_WIDTH / 2.0, 0),
                    new LineTo(WINDOW_WIDTH, WINDOW_HEIGHT / 4.0),
                    new LineTo(WINDOW_WIDTH / 2.0, WINDOW_HEIGHT / 1.3),
                    new ClosePath()
            );
        }

        pathTransition = new PathTransition(Duration.millis(10000), diamondPath, duckView);
        pathTransition.setCycleCount(PathTransition.INDEFINITE);
        pathTransition.setAutoReverse(true);

        pathTransition.setOnFinished(event -> {
            if (pathTransition.getCurrentRate() > 0) {
                duckView.getTransforms().addAll(flipVertical, flipVerHor, flipHorizontal);
            } else {
                duckView.getTransforms().clear();
            }
        });

        pathTransition.play();
        rootPane.getChildren().add(duckView);
    }

    public void duckShot(Pane rootPane, double duckX, double duckY) {
        isShot = true; // flag duck object shot
        // Find and remove the flying duck image view from the root pane
        ImageView flyingDuckView = duckView;
        if (flyingDuckView != null) {
            rootPane.getChildren().remove(flyingDuckView);
        }

        // Pause the flyL2R animation
        if (getStraightOrPentagon()) {
            flyL2RTrTransition.stop();
            wingFlappingTimeline.stop();
        }

        // Pause the flyPentagon animation
        if (!getStraightOrPentagon()) {
            pathTransition.stop();
        }

        // Create the duck shot image view and transition
        ImageView duckShotView = new ImageView(duckShot);
        duckShotView.setFitWidth(DUCK_WIDTH);
        duckShotView.setFitHeight(DUCK_HEIGHT);

        TranslateTransition duckShotTrTransition = new TranslateTransition(Duration.millis(150), duckShotView);
        duckShotTrTransition.setFromX(duckX);
        duckShotTrTransition.setToX(duckX);
        duckShotTrTransition.setFromY(duckY);
        duckShotTrTransition.setToY(duckY + 5);
        duckShotTrTransition.play();

        // Get the index of the foreground image list and add the duck shot image view at the same position
        int index = rootPane.getChildren().indexOf(fgImageList.get(currentBG));
        rootPane.getChildren().add(index, duckShotView);

        // Set the action to perform after the duck shot transition finishes
        duckShotTrTransition.setOnFinished(event -> {
            // Remove the duck shot image view
            rootPane.getChildren().remove(duckShotView);

            // Create the duck fall image view and transition
            ImageView duckFallView = new ImageView(duckFall);
            duckFallView.setFitWidth(DUCK_WIDTH);
            duckFallView.setFitHeight(DUCK_HEIGHT);

            TranslateTransition duckFallTrTransition = new TranslateTransition(Duration.millis(2000), duckFallView);
            duckFallTrTransition.setFromX(duckX);
            duckFallTrTransition.setToX(duckX);
            duckFallTrTransition.setFromY(duckY + 5);
            duckFallTrTransition.setToY(WINDOW_HEIGHT);
            duckFallTrTransition.play();

            // Get the index of the foreground image list and add the duck fall image view at the same position
            int index2 = rootPane.getChildren().indexOf(fgImageList.get(currentBG));
            rootPane.getChildren().add(index2, duckFallView);

            // Remove the flying duck view if it still exists
            if (flyingDuckView != null) {
                rootPane.getChildren().remove(flyingDuckView);
            }
        });
    }

    /**

     Returns the x-coordinate of the duck's current position.
     @param straightOrPentagon Flag indicating whether the duck is flying straight or in a pentagon path.
     @return The x-coordinate of the duck's position.
     */
    public double getX(boolean straightOrPentagon) {
        if (straightOrPentagon && flyL2RTrTransition != null) {
            return flyL2RTrTransition.getNode().getTranslateX();
        }
        if (!straightOrPentagon && pathTransition != null) {
            return pathTransition.getNode().getTranslateX();
        }
        return 0;
    }
    /**

     Returns the y-coordinate of the duck's current position.
     @param straightOrPentagon Flag indicating whether the duck is flying straight or in a pentagon path.
     @return The y-coordinate of the duck's position.
     */
    public double getY(boolean straightOrPentagon) {
        if (flyL2RTrTransition != null) {
            return flyL2RTrTransition.getNode().getTranslateY();
        }
        if (!straightOrPentagon && pathTransition != null) {
            return pathTransition.getNode().getTranslateY();
        }
        return 0;
    }
    /**

     Returns whether the duck is flying straight or in a pentagon path.
     @return True if the duck is flying straight, false if it is flying in a pentagon path.
     */
    public boolean getStraightOrPentagon() {
        return straightOrPentagon;
    }
    public boolean isShot(){
        return isShot;
    }
}
