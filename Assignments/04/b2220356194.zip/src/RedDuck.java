public class RedDuck extends Duck {
    public RedDuck() {
        super(3); // Pass the duck color number to the superclass constructor
    }

}