import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;

/**
 * Presents the title screen GUI for the Duck Hunt game.
 */
public class TitleScreenGUI extends DuckHuntGame {
    private Scene titleScene;

    /**
     * Constructs a new instance of TitleScreenGUI and initializes its components.
     */
    public TitleScreenGUI() {
        super(scale,volume, primaryStage, WINDOW_WIDTH, WINDOW_HEIGHT);
        initializeComponents();
    }

    /**
     * Initializes the components of the title screen.
     */
    private void initializeComponents() {
        Pane titleRoot = new Pane();
        ImageView welcomeImageView = loadImageViewFitted("assets/welcome/1.png");
        titleAudio = loadMediaPlayer("assets/effects/Title.mp3");
        titleAudio.setCycleCount(MediaPlayer.INDEFINITE);
        titleAudio.play();
        Label titleLabel = createLabel("PRESS ENTER TO ENTER\n   PRESS ESC TO EXIT", 0.15, 0.65, 0.05);
        fadeTransition(titleLabel);

        EventHandler<KeyEvent> keyEventHandler = event -> {
            if (event.getCode() == KeyCode.ENTER) {
                BackgroundSelectionGUI backgroundSelectionGUI = new BackgroundSelectionGUI();
                backgroundSelectionGUI.show(titleAudio);
            } else if (event.getCode() == KeyCode.ESCAPE) {
                System.exit(0);
            }
        };

        titleRoot.getChildren().addAll(welcomeImageView, titleLabel);
        titleRoot.prefWidthProperty().bind(primaryStage.widthProperty());
        titleRoot.prefHeightProperty().bind(primaryStage.heightProperty());
        titleRoot.setOnKeyPressed(keyEventHandler);

        titleScene = new Scene(titleRoot);
        titleScene.setOnKeyPressed(keyEventHandler);
    }

    /**
     * Shows the title screen GUI.
     */
    public void show() {
        primaryStage.setScene(titleScene);
        primaryStage.show();
    }
}
