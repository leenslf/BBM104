import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;

/**
 * Presents the background selection GUI for the Duck Hunt game.
 */
public class BackgroundSelectionGUI extends DuckHuntGame{
    private static Label introLabel;
    private final Pane backgroundSelectionRoot;
    Scene chooseBackgroundScene;
    boolean enterPressed = false; // Flag to track if Enter key has been processed

    public BackgroundSelectionGUI() {
        super(scale,volume, primaryStage, WINDOW_WIDTH, WINDOW_HEIGHT);
        currentBG = 0;
        currentCH = 0;
        backgroundSelectionRoot = new Pane();
        introLabel = createLabel("USE ARROW KEYS TO NAVIGATE\n   PRESS ENTER TO START", 0.15, 0.15,0.05);
    }

    /**
     * Shows the background selection GUI.
     *
     * @param titleAudio The MediaPlayer for the title audio.
     */
    public void show(MediaPlayer titleAudio) {

        EventHandler<KeyEvent> keyEventHandler = event -> {
            if (event.getCode() == KeyCode.ENTER && !enterPressed) {
                enterPressed = true; // Set the flag to true
                titleAudio.stop(); // stop title audio in Background selection screen
                GameScreen game = new GameScreen(currentBG, currentCH); // create game object with chosen Background and Cross-hair image
                game.startGame(); // start game
            } else if (event.getCode() == KeyCode.UP) {
                currentCH = (currentCH + 1) % cHImageList.size(); // Change cross-hair image index to the next one
                backgroundSelectionRoot.getChildren().set(1, cHImageList.get(currentCH));

            } else if (event.getCode() == KeyCode.DOWN) {
                currentCH = (currentCH + cHImageList.size() - 1) % cHImageList.size(); // Change cross-hair image index to the previous one
                backgroundSelectionRoot.getChildren().set(1, cHImageList.get(currentCH));

            } else if (event.getCode() == KeyCode.RIGHT) {
                currentBG = (currentBG + 1) % bgImageList.size(); // Change background image index to the next one
                backgroundSelectionRoot.getChildren().set(0, bgImageList.get(currentBG));

            } else if (event.getCode() == KeyCode.LEFT) {
                currentBG = (currentBG + bgImageList.size() - 1) % bgImageList.size(); // Change background image index to the previous one
                backgroundSelectionRoot.getChildren().set(0, bgImageList.get(currentBG));
            }
            else if (event.getCode() == KeyCode.ESCAPE) {
                TitleScreenGUI titleScreen = new TitleScreenGUI();
                titleScreen.show();
            }
        };

        backgroundSelectionRoot.getChildren().addAll(bgImageList.get(currentBG), cHImageList.get(currentCH), introLabel);
        backgroundSelectionRoot.prefWidthProperty().bind(primaryStage.widthProperty());
        backgroundSelectionRoot.prefHeightProperty().bind(primaryStage.heightProperty());
        backgroundSelectionRoot.setOnKeyPressed(keyEventHandler);
        chooseBackgroundScene = new Scene(backgroundSelectionRoot);
        chooseBackgroundScene.setOnKeyPressed(keyEventHandler);
        primaryStage.setScene(chooseBackgroundScene);
        primaryStage.show();
    }

}
