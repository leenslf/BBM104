import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import java.util.ArrayList;
import java.util.List;


/**
 * Represents the game screen of Duck Hunt.
 */
public class GameScreen extends DuckHuntGame {
    private final int currentBG;
    private final int currentCH;
    private Label ammoLeftLabel;
    private Label youWinLabel;
    private Label playNextLevelLabel;
    List<Duck> duckList;
    private int level;
    private int ammo;
    private MediaPlayer gunshotSound;
    MediaPlayer introAudio = loadMediaPlayer("assets/effects/Intro.mp3");
    boolean introPlayedOnce = false;

    /**
     * Constructor for the GameScreen class.
     *
     * @param currentBG The index of the current background
     * @param currentCH The index of the current cursor image
     */
    public GameScreen(int currentBG, int currentCH) {
        super(scale,volume, primaryStage, WINDOW_WIDTH, WINDOW_HEIGHT);
        this.currentBG = currentBG;
        this.currentCH = currentCH;
    }

    /**
     * Start the game from level1 and play intro music
     */
    public void startGame() {
        if (!introPlayedOnce){ // ensure that playing again from the end of the game does not play the sound effect again.
            introAudio.play();
            introPlayedOnce = true;
            introAudio.setOnEndOfMedia(() -> {
                setLevel(1);
                setupLevelScene();
            });
        } else{
            setLevel(1);
            setupLevelScene();
        }
    }

    /**
     * Sets up the level scene.
     * This method creates the graphical elements and event handlers for a specific level.
     * It sets up the background, ducks, labels, cursor, and event listeners for shooting ducks.
     */
    private void setupLevelScene() {
        Pane root = new Pane();
        Scene scene = new Scene(root);
        Label levelLabel = createLabel("Level " + getLevel(), 0.4, 0, 0.030);
        ammoLeftLabel = createLabel("Ammo left: " + getAmmo(), 0.75, 0, 0.030);
        Cursor cursor = new ImageCursor(cHImageList.get(currentCH).getImage());
        root.setCursor(cursor);
        int currentLevel = getLevel();
        duckList = new ArrayList<>();
        root.getChildren().addAll(bgImageList.get(currentBG));
        createDucks(root, currentLevel, duckList);
        root.getChildren().addAll(fgImageList.get(currentBG), levelLabel, ammoLeftLabel);

        // Set up event listener for the ESCAPE key to allow the player to return to the background selection screen by pressing ESC
        scene.setOnKeyPressed(keyEvent -> {
            if (keyEvent.getCode() == KeyCode.ESCAPE) {
                TitleScreenGUI titleScreenGUI = new TitleScreenGUI();
                titleScreenGUI.show();
            }
        });

        // Set up event listener for mouse click to shoot the ducks based on the current level
        scene.setOnMouseClicked(event -> {
            switch (currentLevel) {
                case 1:
                case 2:
                    handleMouseClicked1Duck(event, duckList.get(0), root, scene, currentLevel);
                    break;
                case 3:
                case 4:
                    handleMouseClicked2Duck(event, duckList.get(0), duckList.get(1), root, scene, currentLevel);
                    break;
                case 5:
                case 6:
                    handleMouseClicked3Duck(event, duckList.get(0), duckList.get(1), duckList.get(2), root, scene, currentLevel);
                    break;
                default:
                    break;
            }
        });

        root.prefWidthProperty().bind(primaryStage.widthProperty());
        root.prefHeightProperty().bind(primaryStage.heightProperty());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Handles the mouse click event for shooting one duck in the game.
     *
     * @param event        The MouseEvent representing the mouse click event.
     * @param duck         The Duck object representing the duck being clicked.
     * @param root         The Pane object representing the root pane of the scene.
     * @param scene        The Scene object representing the game scene.
     * @param currentLevel The current level of the game.
     */
    private void handleMouseClicked1Duck(MouseEvent event, Duck duck, Pane root, Scene scene, int currentLevel) {
        if (event.getButton() == MouseButton.PRIMARY) {
            if (duck.isShot()) {
                return;
            }

            gunshotSound = loadMediaPlayer("assets/effects/Gunshot.mp3");
            gunshotSound.play();
            double clickX = event.getX();
            double clickY = event.getY();
            boolean straightOrPentagon = duck.getStraightOrPentagon();
            double duckX = duck.getX(straightOrPentagon);
            double duckY = duck.getY(straightOrPentagon);

            // Check if the click is close enough to the duck's position to be considered a hit
            if (Math.abs(clickX - duckX) <= 50 && Math.abs(clickY - duckY) <= 50) {
                // Handle the duck shot
                handleDuckShot(duck, root, duckX, duckY);


                // Check if all ducks have been shot
                if (duck.isShot()) {
                    // Player won the level
                    levelWon(root);

                    // Set up event listener for ENTER key to proceed to the next level
                    scene.setOnKeyPressed(keyEvent -> {
                        if (keyEvent.getCode() == KeyCode.ENTER) {
                            nextLevel(root);
                        }
                    });
                }
            } else if (getAmmo() > 1) {
                // Decrease ammo if the shot missed and there is more than 1 ammo remaining
                decreaseAmmo();
                ammoLeftLabel.setText("Ammo left: " + getAmmo());
            } else if (getAmmo() == 1) {
                // Decrease ammo if the shot missed and there is only 1 ammo remaining
                decreaseAmmo();
                ammoLeftLabel.setText("Ammo left: " + getAmmo());

                // Game over
                gameOver(root);

                // Set up event listener for ENTER key to restart the level or ESCAPE key to exit the game
                scene.setOnKeyPressed(keyEvent -> {
                    if (keyEvent.getCode() == KeyCode.ENTER) {
                        setLevel(currentLevel);
                        setupLevelScene();
                    }if (keyEvent.getCode() == KeyCode.ESCAPE) {
                        TitleScreenGUI titleScreen = new TitleScreenGUI();
                        titleScreen.show();
                    }
                });
            }
        }
    }

    /**
     * Handles the mouse click event for shooting two ducks in the game.
     *
     * @param event         The MouseEvent representing the mouse click event.
     * @param duck1         The first Duck object to check for a hit.
     * @param duck2         The second Duck object to check for a hit.
     * @param root          The Pane object representing the root pane of the scene.
     * @param scene         The Scene object representing the game scene.
     * @param currentLevel  The current level of the game.
     */
    private void handleMouseClicked2Duck(MouseEvent event, Duck duck1, Duck duck2, Pane root, Scene scene, int currentLevel) {
        if (event.getButton() == MouseButton.PRIMARY) {
            if (duck1.isShot() && duck2.isShot()) {
                return;
            }

            gunshotSound = loadMediaPlayer("assets/effects/Gunshot.mp3");
            gunshotSound.play();
            double clickX = event.getX();
            double clickY = event.getY();
            double[] duckXArray = {duck1.getX(duck1.getStraightOrPentagon()), duck2.getX(duck2.getStraightOrPentagon())};
            double[] duckYArray = {duck1.getY(duck1.getStraightOrPentagon()), duck2.getY(duck2.getStraightOrPentagon())};

            // Check if the click is close enough to each duck's position to be considered a hit
            for (int i = 0; i < duckXArray.length; i++) {
                if (Math.abs(clickX - duckXArray[i]) <= 30 && Math.abs(clickY - duckYArray[i]) <= 30) {
                    // Handle the duck shot
                    handleDuckShot(i == 0 ? duck1 : duck2, root, duckXArray[i], duckYArray[i]);
//                    numDucksShot++;
                }
            }

//            // Update the number of remaining ducks based on the number of ducks shot
//            if (numDucksShot == 2) {
//                numDucks -= 2;
//            } else if (numDucksShot == 1) {
//                numDucks--;
//            }

            // Check if all ducks have been shot
            if (duck1.isShot() && duck2.isShot()) {
                // Player won the level
                levelWon(root);

                // Set up event listener for ENTER key to proceed to the next level
                scene.setOnKeyPressed(keyEvent -> {
                    if (keyEvent.getCode() == KeyCode.ENTER) {
                        nextLevel(root);
                    }
                });
            } else if (getAmmo() > 1) {
                // Decrease ammo if the shot missed and there is more than 1 ammo remaining
                decreaseAmmo();
                ammoLeftLabel.setText("Ammo left: " + getAmmo());
            } else if (getAmmo() == 1) {
                // Decrease ammo if the shot missed and there is only 1 ammo remaining
                decreaseAmmo();
                ammoLeftLabel.setText("Ammo left: " + getAmmo());

                // Game over
                gameOver(root);

                // Set up event listener for ENTER key to restart the level or ESCAPE key to exit the game
                scene.setOnKeyPressed(keyEvent -> {
                    if (keyEvent.getCode() == KeyCode.ENTER) {
                        setLevel(currentLevel);
                        setupLevelScene();
                    } if (keyEvent.getCode() == KeyCode.ESCAPE) {
                        TitleScreenGUI titleScreen = new TitleScreenGUI();
                        titleScreen.show();
                    }
                });
            }
        }
    }

    /**
     * Handles the mouse click event for shooting three ducks in the game.
     *
     * @param event         The MouseEvent representing the mouse click event.
     * @param duck1         The first Duck object to check for a hit.
     * @param duck2         The second Duck object to check for a hit.
     * @param duck3         The third Duck object to check for a hit.
     * @param root          The Pane object representing the root pane of the scene.
     * @param scene         The Scene object representing the game scene.
     * @param currentLevel  The current level of the game.
     */
    private void handleMouseClicked3Duck(MouseEvent event, Duck duck1, Duck duck2, Duck duck3, Pane root, Scene scene, int currentLevel) {
        if (event.getButton() == MouseButton.PRIMARY) {
            if (duck1.isShot() && duck2.isShot() && duck3.isShot()) {
                return;
            }

            gunshotSound = loadMediaPlayer("assets/effects/Gunshot.mp3");
            gunshotSound.play();
            double clickX = event.getX();
            double clickY = event.getY();
            double[] duckXArray = {
                    duck1.getX(duck1.getStraightOrPentagon()),
                    duck2.getX(duck2.getStraightOrPentagon()),
                    duck3.getX(duck3.getStraightOrPentagon())
            };
            double[] duckYArray = {
                    duck1.getY(duck1.getStraightOrPentagon()),
                    duck2.getY(duck2.getStraightOrPentagon()),
                    duck3.getY(duck3.getStraightOrPentagon())
            };
//            numDucksShot = 0;

            // Check if the click is close enough to each duck's position to be considered a hit
            for (int i = 0; i < duckXArray.length; i++) {
                if (Math.abs(clickX - duckXArray[i]) <= 30 && Math.abs(clickY - duckYArray[i]) <= 30) {
                    // Handle the duck shot
                    handleDuckShot(i == 0 ? duck1 : (i == 1 ? duck2 : duck3), root, duckXArray[i], duckYArray[i]);
                }
            }

            // Check if all ducks have been shot
            if (duck1.isShot() && duck2.isShot() && duck3.isShot()) {
                if (currentLevel == 6) {
                    // Game over after completing the final level
                    endGame(root, scene);
                } else {
                    // Player won the level
                    levelWon(root);

                    // Set up event listener for ENTER key to proceed to the next level
                    scene.setOnKeyPressed(keyEvent -> {
                        if (keyEvent.getCode() == KeyCode.ENTER) {
                            nextLevel(root);
                        }
                    });
                }
            } else if (getAmmo() > 1) {
                // Decrease ammo if the shot missed and there is more than 1 ammo remaining
                decreaseAmmo();
                ammoLeftLabel.setText("Ammo left: " + getAmmo());
            } else if (getAmmo() == 1) {
                // Decrease ammo if the shot missed and there is only 1 ammo remaining
                decreaseAmmo();
                ammoLeftLabel.setText("Ammo left: " + getAmmo());

                // Game over
                gameOver(root);

                // Set up event listener for ENTER key to restart the level or ESCAPE key to exit the game
                scene.setOnKeyPressed(keyEvent -> {
                    if (keyEvent.getCode() == KeyCode.ENTER) {
                        setLevel(currentLevel);
                        setupLevelScene();
                    } if (keyEvent.getCode() == KeyCode.ESCAPE) {
                        TitleScreenGUI titleScreen = new TitleScreenGUI();
                        titleScreen.show();
                    }
                });
            }
        }
    }

    /**
     * Handles the shot of a duck.
     *
     * @param duck    The Duck object that was shot.
     * @param root    The Pane object representing the root pane of the scene.
     * @param duckX   The x-coordinate of the duck's position.
     * @param duckY   The y-coordinate of the duck's position.
     */
    private void handleDuckShot(Duck duck, Pane root, double duckX, double duckY) {
        if (duck.isShot()){
            return; // This ensures duckShot() method is not triggered AGAIN in case the duck has already been shot
        } else{
            MediaPlayer duckFallsSound = loadMediaPlayer("assets/effects/DuckFalls.mp3");
            duckFallsSound.play();
            duck.duckShot(root, duckX, duckY);
        }
    }

    /**
     * Creates ducks based on the current level and adds them to the duck list.
     *
     * @param root          The Pane object representing the root pane of the scene.
     * @param currentLevel  The current level of the game.
     * @param ducklist      The list of ducks to add the created ducks to.
     */
    private void createDucks(Pane root, int currentLevel, List<Duck> ducklist) {
        if (currentLevel == 1) {
            Duck blackDuck = new BlackDuck();
            blackDuck.flyL2R(root, true);
            ducklist.add(blackDuck);
        } else if (currentLevel == 2) {
            Duck blueDuck = new BlueDuck();
            blueDuck.flyPentagon(root, true); // modify this later
            ducklist.add(blueDuck);
        } else if (currentLevel == 3) {
            Duck blueDuck = new BlueDuck();
            Duck blackDuck = new BlackDuck();
            blackDuck.flyL2R(root, true);
            blueDuck.flyL2R(root, false);
            ducklist.add(blueDuck);
            ducklist.add(blackDuck);
        } else if (currentLevel == 4) {
            Duck blackDuck = new BlackDuck();
            Duck blueDuck = new BlueDuck();
            blackDuck.flyPentagon(root, true);
            blueDuck.flyPentagon(root, false); // one of them should be opposite
            ducklist.add(blueDuck);
            ducklist.add(blackDuck);
        } else if (currentLevel == 5) {
            Duck blackDuck = new BlackDuck();
            Duck blueDuck = new BlueDuck();
            Duck redDuck = new RedDuck();
            blackDuck.flyL2R(root, true);
            blueDuck.flyL2R(root, false);
            redDuck.flyPentagon(root, true);
            ducklist.add(blueDuck);
            ducklist.add(blackDuck);
            ducklist.add(redDuck);
        } else if (currentLevel == 6) {
            Duck blackDuck = new BlackDuck();
            Duck blueDuck = new BlueDuck();
            Duck redDuck = new RedDuck();
            blackDuck.flyPentagon(root, true);
            blueDuck.flyL2R(root, false);
            redDuck.flyPentagon(root, false);
            ducklist.add(blueDuck);
            ducklist.add(blackDuck);
            ducklist.add(redDuck);
        }
    }

    /**
     * Displays the "You Win!" message and the "Press Enter to play next level" message on the screen.
     *
     * @param root The Pane object representing the root pane of the scene.
     */
    public void levelWon(Pane root) {
        youWinLabel = createLabel("      You Win!", 0.2, 0.40, 0.070);
        playNextLevelLabel = createLabel("Press Enter to play next level", 0.15, 0.50, 0.050);
        fadeTransition(playNextLevelLabel);
        root.getChildren().addAll(youWinLabel, playNextLevelLabel);
    }

    /**
     * Proceeds to the next level of the game.
     *
     * @param root The Pane object representing the root pane of the scene.
     */
    private void nextLevel(Pane root) {
        root.getChildren().removeAll(youWinLabel, playNextLevelLabel);
        int currentLevel = getLevel();
        if (currentLevel < 6) {
            MediaPlayer levelCompletedSound = loadMediaPlayer("assets/effects/LevelCompleted.mp3");
            levelCompletedSound.play();
            setLevel(++currentLevel);
            setupLevelScene();
        }
    }

    /**
     * Displays the "GAME OVER!" message and the "Press ENTER to play again, Press ESC to exit" message on the screen.
     *
     * @param root The Pane object representing the root pane of the scene.
     */
    private void gameOver(Pane root) {
        MediaPlayer gameOverSound = loadMediaPlayer("assets/effects/GameOver.mp3");
        gameOverSound.play();
        Label gameOverLabel = createLabel("       GAME OVER!", 0.2, 0.2, 0.050);
        playNextLevelLabel = createLabel("Press ENTER to play again\n    Press ESC to exit", 0.15, 0.50, 0.050);
        fadeTransition(playNextLevelLabel);
        root.getChildren().addAll(gameOverLabel, playNextLevelLabel);
    }

    /**
     * Displays the "You completed the game!" message and the "Press ENTER to play again, Press ESC to exit" message on the screen.
     * Allows the user to restart the game or exit the application.
     *
     * @param root  The Pane object representing the root pane of the scene.
     * @param scene The Scene object representing the game scene.
     */
    private void endGame(Pane root, Scene scene) {
        MediaPlayer gameCompletedSound = loadMediaPlayer("assets/effects/GameCompleted.mp3");
        gameCompletedSound.play();
        youWinLabel = createLabel("You completed the game!", 0.10, 0.40, 0.065);
        playNextLevelLabel = createLabel("Press ENTER to play again\n    Press ESC to exit", 0.15, 0.50, 0.050);
        fadeTransition(playNextLevelLabel);
        root.getChildren().addAll(youWinLabel, playNextLevelLabel);
        scene.setOnKeyPressed(keyEvent -> {
            if (keyEvent.getCode() == KeyCode.ENTER) {
                startGame();
            } else if (keyEvent.getCode() == KeyCode.ESCAPE) {
                System.exit(0);
            }
        });
    }

    /**
     * Sets the ammo count to the specified value.
     *
     * @param ammo The new ammo count.
     */
    public void setAmmo(int ammo) {
        this.ammo = ammo;
    }

    /**
     * Decreases the ammo count by 1.
     */
    public void decreaseAmmo() {
        ammo--;
    }

    /**
     * Returns the current ammo count.
     *
     * @return The current ammo count.
     */
    public int getAmmo() {
        return ammo;
    }

    /**
     * Returns the current level.
     *
     * @return The current level.
     */
    public int getLevel() {
        return level;
    }




    /**
     * Sets the current level and updates the ammo count based on the level.
     *
     * @param level The new level.
     */
    public void setLevel(int level) {
        this.level = level;
        if (level <= 2) {
            setAmmo(3);
        } else if (level <= 4) {
            setAmmo(6);
        } else if (level <= 6) {
            setAmmo(9);
        }
    }

}
