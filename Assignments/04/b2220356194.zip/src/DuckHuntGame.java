import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Class representing the Duck Hunt game.
 */
public class DuckHuntGame {
    protected static double scale;
    protected static double volume;
    protected static int WINDOW_WIDTH;
    protected static int WINDOW_HEIGHT;
    protected static Stage primaryStage;
    protected static List<ImageView> bgImageList = new ArrayList<>();
    protected static List<ImageView> cHImageList = new ArrayList<>();
    protected static List<ImageView> fgImageList = new ArrayList<>();
    protected MediaPlayer titleAudio;
    protected static int currentBG;
    protected static int currentCH;

    /**
     * Constructor for the DuckHuntGame class.
     *
     * @param scale         The scale value.
     * @param volume        The volume value.
     * @param primaryStage The primary stage of the game.
     * @param WINDOW_WIDTH  The width of the game window.
     * @param WINDOW_HEIGHT The height of the game window.
     */
    public DuckHuntGame(double scale, double volume, Stage primaryStage, int WINDOW_WIDTH, int WINDOW_HEIGHT) {
        DuckHuntGame.scale = scale;
        DuckHuntGame.volume = volume;
        DuckHuntGame.primaryStage = primaryStage;
        DuckHuntGame.WINDOW_HEIGHT = WINDOW_HEIGHT;
        DuckHuntGame.WINDOW_WIDTH = WINDOW_WIDTH;
    }

    /**
     * Starts the Duck Hunt game.
     */
    public void start() {
        for (int i = 1; i <= 6; i++) {
            String bgImagePath = "/assets/background/" + i + ".png";
            ImageView bgImageView = loadImageViewFitted(bgImagePath);
            bgImageList.add(bgImageView);
        }
        for (int i = 1; i <= 6; i++) {
            String fgImagePath = "/assets/foreground/" + i + ".png";
            ImageView fgImageView = loadImageViewFitted(fgImagePath);
            fgImageList.add(fgImageView);
        }
        for (int i = 1; i <= 7; i++) {
            String cHImagePath = "/assets/crosshair/" + i + ".png";
            ImageView cHImageView = loadImageView(cHImagePath);
            cHImageView.setScaleX(3); // Scale horizontally by 3
            cHImageView.setScaleY(3); // Scale vertically by 3
            cHImageView.setX(primaryStage.getWidth() / 2 - cHImageView.getBoundsInLocal().getWidth() / 2); // Position horizontally at the center of the screen
            cHImageView.setY(primaryStage.getHeight() / 2 - cHImageView.getBoundsInLocal().getHeight() / 2); // Position vertically at the center of the screen
            cHImageList.add(cHImageView);
        }

        TitleScreenGUI titleScreen = new TitleScreenGUI();
        titleScreen.show();
    }

    /**
     * Returns the scale value.
     *
     * @return The scale value.
     */
    public static double getScale() {
        return scale;
    }

    /**
     * Returns the volume value.
     *
     * @return The volume value.
     */
    public static double getVolume() {
        return volume;
    }


    /**
     * Loads an ImageView fitted to the primary stage dimensions.
     *
     * @param imagePath The path of the image.
     * @return The loaded ImageView.
     */
    public ImageView loadImageViewFitted(String imagePath) {
        Image image = new Image(imagePath);
        ImageView imageView = new ImageView(image);
        imageView.setPreserveRatio(true);
        imageView.fitWidthProperty().bind(primaryStage.widthProperty());
        imageView.fitHeightProperty().bind(primaryStage.heightProperty());
        return imageView;
    }

    /**
     * Loads an ImageView without fitting to the primary stage dimensions.
     *
     * @param imagePath The path of the image.
     * @return The loaded ImageView.
     */
    public ImageView loadImageView(String imagePath) {
        Image image = new Image(imagePath);
        ImageView imageView = new ImageView(image);
        imageView.setPreserveRatio(true);
        return imageView;
    }

    /**
     * Loads an Image.
     *
     * @param imagePath The path of the image.
     * @return The loaded Image.
     */
    public Image loadImage(String imagePath) {
        return new Image(imagePath);
    }

    /**
     * Loads a MediaPlayer for the specified media path.
     *
     * @param mediaPath The path of the media.
     * @return The loaded MediaPlayer.
     */
    public static MediaPlayer loadMediaPlayer(String mediaPath) {
        Media sound = new Media(Objects.requireNonNull(DuckHunt.class.getResource(mediaPath)).toExternalForm());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.setVolume(getVolume());
        return mediaPlayer;
    }

    /**
     * Creates a Label with the specified properties.
     *
     * @param labelString The text of the label.
     * @param xProperty   The x-position property.
     * @param yProperty   The y-position property.
     * @param fontSize    The font size.
     * @return The created Label.
     */
    public static Label createLabel(String labelString, double xProperty, double yProperty, double fontSize) {
        Label label = new Label(labelString);
        label.setFont(Font.font("Arial", FontWeight.BOLD, fontSize * primaryStage.getWidth()));
        label.setTextFill(Color.ORANGE);
        label.layoutXProperty().bind(primaryStage.widthProperty().multiply(xProperty));
        label.layoutYProperty().bind(primaryStage.heightProperty().multiply(yProperty));
        return label;
    }

    /**
     * Performs a fade transition on the specified Label.
     *
     * @param label The Label to apply the fade transition.
     */
    public void fadeTransition(Label label) {
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(0.45), label);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.0);
        fadeTransition.setAutoReverse(true);
        fadeTransition.setCycleCount(Timeline.INDEFINITE);
        fadeTransition.play();
    }
}
