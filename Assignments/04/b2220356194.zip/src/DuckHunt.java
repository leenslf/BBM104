import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * The main class for the Duck Hunt game application.
 */
public class DuckHunt extends Application {
    private static double scale;
    private static double volume;
    protected static int WINDOW_WIDTH = 600 ;
    protected static int WINDOW_HEIGHT = 600;
    static Stage primaryStage;

    /**
     * Default constructor for the DuckHunt class.
     * Initializes the default scale factor and volume value.
     */
    public DuckHunt() {
        scale = 3.5; // Default scale factor
        volume = 0.1; // Default volume value
    }

    /**
     * The entry point for the application.
     *
     * @param args The command-line arguments.
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Set up the game window
        DuckHunt.primaryStage = primaryStage; // Assign the value to the static variable
        primaryStage.setTitle("Duck Hunt");
        primaryStage.setWidth(WINDOW_WIDTH);
        primaryStage.setHeight(WINDOW_HEIGHT);

        // Set the favicon for the stage
        Image favicon = new Image("assets/favicon/1.png");
        primaryStage.getIcons().add(favicon);

        DuckHuntGame duckHuntGame = new DuckHuntGame(scale, volume, primaryStage, WINDOW_WIDTH, WINDOW_HEIGHT);
        duckHuntGame.start();
        primaryStage.show();
    }
}
