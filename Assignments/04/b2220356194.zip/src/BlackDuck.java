public class BlackDuck extends Duck {
    public BlackDuck() {
        super(1); // Pass the duck color number to the superclass constructor
    }

}