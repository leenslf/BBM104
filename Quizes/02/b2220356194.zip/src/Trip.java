import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Trip implements Comparable<Trip>{
    private String tripName;
    private String state = "IDLE";
    private LocalTime departureTime;
    private int duration;
    private LocalTime arrivalTime;


    public static Trip[] read(String[] file) {
        int numTrips = file.length;
        Trip[] trips = new Trip[numTrips];
        for (int i = 0; i < numTrips; i++) {
            String[] tokens = file[i].split("\t");
            String tripName = tokens[0];
            LocalTime departureTime = LocalTime.parse(tokens[1], DateTimeFormatter.ofPattern("HH:mm"));
            int duration = Integer.parseInt(tokens[2]);
            Trip trip = new Trip(tripName, departureTime, duration);
            trips[i] = trip;
        }
        return trips;
    }
    public Trip(String tripName, LocalTime departureTime, int duration) {
        this.tripName = tripName;
        this.departureTime = departureTime;
        this.duration = duration;
        this.arrivalTime = this.calculateArrivalTime();
    }

    public LocalTime calculateArrivalTime() {
        return this.departureTime.plusMinutes(this.duration);
    }
    public String getTripName(){
        return tripName;
    }
    public LocalTime getDepartureTime(){
        return departureTime;
    }
    public LocalTime getArrivalTime(){
        return arrivalTime;
    }
    public String getState(){
        return state;
    }
    public void setState(String state){
        this.state = state;
    }

    @Override
    public int compareTo(Trip other) {
        return this.getDepartureTime().compareTo(other.getDepartureTime());
    }
}
