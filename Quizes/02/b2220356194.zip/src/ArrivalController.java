import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ArrivalController {
    public static void arrivalSchedule(Trip[] trips){
        if (trips != null) {
            Arrays.sort(trips, Comparator.comparing(Trip::getArrivalTime));
        }
        System.out.println("Arrival order:");
        TripController.writeUsingFileWriter("Arrival order:\n");
        LocalTime repeated = null;
        List<LocalTime> arrivalTimes = new ArrayList<>();

        if (trips != null) {
            for (Trip trip : trips) {
                LocalTime arrivalTime = trip.getArrivalTime();
                arrivalTimes.add(arrivalTime);
            }
        }
        for (int i = 0; i < arrivalTimes.size(); i++) {
            for (int j = i + 1; j < arrivalTimes.size(); j++) {
                if (arrivalTimes.get(i).equals(arrivalTimes.get(j))) {
                    repeated = arrivalTimes.get(i);
                    break;
                }
            }
            if (repeated != null) {
                break;
            }
        }
        if (trips != null) {
            for (Trip trip : trips) {
                String tripName = trip.getTripName();
                LocalTime arrivalTime = trip.getArrivalTime();
                w
                System.out.println(tripName + " arrive at " + arrivalTime.format(DateTimeFormatter.ofPattern("HH:mm")) + "    Trip State:" + state);
                TripController.writeUsingFileWriter(tripName + " arrive at " + arrivalTime.format(DateTimeFormatter.ofPattern("HH:mm")) + "    Trip State:" + state + "\n");
            }
        }
        System.out.println();
        TripController.writeUsingFileWriter("\n");
    }
}
