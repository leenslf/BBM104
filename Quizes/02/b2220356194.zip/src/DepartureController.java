import java.util.Arrays;
import java.util.Comparator;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DepartureController {
    public static void departureSchedule(Trip[] trips) {
        if (trips != null) {
            Arrays.sort(trips, Comparator.comparing(Trip::getDepartureTime));
        }
        LocalTime repeated = null;
        List<LocalTime> departureTimes = new ArrayList<>();
        System.out.println("Departure order:");
        TripController.writeUsingFileWriter("Departure order:\n");

        if (trips != null) {
            for (Trip trip : trips) {
                LocalTime departureTime = trip.getDepartureTime();
                departureTimes.add(departureTime);
            }
        }
        for (int i = 0; i < departureTimes.size(); i++) {
            for (int j = i + 1; j < departureTimes.size(); j++) {
                if (departureTimes.get(i).equals(departureTimes.get(j))) {
                    repeated = departureTimes.get(i);
                    break;
                }
            }
            if (repeated != null) {
                break;
            }
        }

        if (trips != null) {
            for (Trip trip : trips) {
                String tripName = trip.getTripName();
                LocalTime departureTime = trip.getDepartureTime();
                String state = repeated != null && departureTime.equals(repeated) ? "DELAYED" : "IDLE";
                trip.setState(state);
                System.out.println(tripName + " depart at " + departureTime.format(DateTimeFormatter.ofPattern("HH:mm")) + "    Trip State:" + state);
                TripController.writeUsingFileWriter(tripName + " depart at " + departureTime.format(DateTimeFormatter.ofPattern("HH:mm")) + "    Trip State:" + state + "\n");
            }
        }
        System.out.println();
        TripController.writeUsingFileWriter("\n");
    }
}
