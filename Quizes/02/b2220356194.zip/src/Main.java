public class Main {
    public static void main(String[] args) {
        String[] file = TripController.readFile("input.txt");
        Trip[] trips = Trip.read(file);
        TripController.DepartureTimes(trips);
        TripController.ArrivalTimes(trips);
    }
}
