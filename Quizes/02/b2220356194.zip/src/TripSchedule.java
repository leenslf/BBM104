public class TripSchedule {
    private int size;
    private Trip[] trips;
    public TripSchedule(int size) {
        this.size = size;
        this.trips = new Trip[size];
    }

    public void addTrip(Trip trip) {
        for (int i = 0; i < trips.length; i++) {
            if (trips[i] == null) {
                trips[i] = trip;
                return;
            }
        }
    }

    public Trip[] getTrips() {
        return trips;
    }

}
