import java.util.NoSuchElementException;

// Generic Queue class using Circular Doubly Linked List
class Queue<T> {
    private final CircularDoublyLinkedList<T> list;

    public Queue() {
        list = new CircularDoublyLinkedList<>();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public int size() {
        return list.size();
    }

    public void enqueue(T item) {
        list.add(item);
    }

    public T dequeue() {
        if (isEmpty())
            throw new NoSuchElementException("Queue is empty.");

        return list.remove();
    }
}
