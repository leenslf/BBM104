import java.util.NoSuchElementException;

// Circular Doubly Linked List class
class CircularDoublyLinkedList<T> {
    private Node<T> head;
    private int size;

    public CircularDoublyLinkedList() {
        this.head = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public int size() {
        return size;
    }

    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) {
            head = newNode;
            head.next = head;
            head.prev = head;
        } else {
            Node<T> lastNode = head.prev;
            lastNode.next = newNode;
            newNode.prev = lastNode;
            newNode.next = head;
            head.prev = newNode;
        }
        size++;
    }

    public T remove() {
        if (isEmpty())
            throw new NoSuchElementException("Circular Doubly Linked List is empty.");

        T data = head.data;
        if (size == 1) {
            head = null;
        } else {
            Node<T> lastNode = head.prev;
            Node<T> newHead = head.next;
            lastNode.next = newHead;
            newHead.prev = lastNode;
            head = newHead;
        }
        size--;
        return data;
    }
}