import java.util.NoSuchElementException;

// Generic Stack class using Circular Doubly Linked List
class Stack<T> {
    private final CircularDoublyLinkedList<T> list;

    public Stack() {
        list = new CircularDoublyLinkedList<>();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public int size() {
        return list.size();
    }

    public void push(T item) {
        list.add(item);
    }

    public T pop() {
        if (isEmpty())
            throw new NoSuchElementException("Stack is empty.");

        return list.remove();
    }
}