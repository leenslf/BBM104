import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sort {
    public static void ascendingSort(List<Integer> listnum) {
        System.out.println("Ascending order sorting:");
        Main.writeUsingFileWriter("Ascending order sorting:\n");
        List<Integer> sortedNumbers;
        for (int i = 0; i < listnum.size(); i++) {
            // Create a new list that contains the first i+1 elements of listnum
            sortedNumbers = new ArrayList<>(listnum.subList(0, i + 1));
            Collections.sort(sortedNumbers);
            // Print the sorted list with spaces in between the elements
            System.out.println(String.join(" ", sortedNumbers.stream().map(Object::toString).toArray(String[]::new)));
            String result = String.join(" ", sortedNumbers.stream().map(Object::toString).toArray(String[]::new));
            Main.writeUsingFileWriter(result);
            Main. writeUsingFileWriter(Main.line);

        }
        Main.writeUsingFileWriter(Main.line);
    }

    public static void descendingSort(List<Integer> listnum) {
        System.out.println("Descending order sorting:");
        Main.writeUsingFileWriter("Descending order sorting:\n");
        List<Integer> sortedNumbers;
        for (int i = 0; i < listnum.size(); i++) {
            // Sort the first i+1 elements of the list
            sortedNumbers = new ArrayList<>(listnum.subList(0, i + 1));
            sortedNumbers.sort(Collections.reverseOrder());
            // Print the sorted list with spaces in between the elements
            System.out.println(String.join(" ", sortedNumbers.stream().map(Object::toString).toArray(String[]::new)));
            String result = String.join(" ", sortedNumbers.stream().map(Object::toString).toArray(String[]::new));
            Main.writeUsingFileWriter(result);
            Main.writeUsingFileWriter(Main.line);
        }
        Main.writeUsingFileWriter(Main.line);
    }
}
