import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class Main {
    public static String line= "\n";
    public static String tline= "\n\n";
    public static void writeUsingFileWriter(String data) {
        File file = new File("output.txt");
        FileWriter fr = null;
        try {
            fr = new FileWriter(file, true);
            fr.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //close resources
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
    }

    public static void main(String[] args) {
        try {
            // Open input and output files
            File inputFile = new File("input.txt");
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            String line = null;
            while ((line = br.readLine()) != null) {
                line = line.trim();

                if (line.equals("Armstrong numbers up to:")) {
                    int armstrongLimit = Integer.parseInt(br.readLine().trim());
                    ArmstrongNumbers.printArmstrongNumbers(armstrongLimit);
                } else if (line.equals("Emirp numbers up to:")) {
                    int emirpLimit = Integer.parseInt(br.readLine().trim());
                    EmripNumbers.printEmripNumbers(emirpLimit);
                } else if (line.equals("Abundant numbers up to:")) {
                    int abundantLimit = Integer.parseInt(br.readLine().trim());
                    AbundantNumbers.printAbundantNumbers(abundantLimit);
                } else if (line.equals("Ascending order sorting:")) {
                    List<Integer> numbers = new ArrayList<>();
                    String nextLine;
                    while ((nextLine = br.readLine()) != null && !nextLine.trim().equals("-1")) {
                        int number = Integer.parseInt(nextLine.trim());
                        numbers.add(number);
                    }
                    Sort.ascendingSort(numbers);
                } else if (line.equals("Descending order sorting:")) {
                    List<Integer> numbers = new ArrayList<>();
                    String nextLine2;
                    while ((nextLine2 = br.readLine()) != null && !nextLine2.trim().equals("-1")) {
                        int number = Integer.parseInt(nextLine2.trim());
                        numbers.add(number);
                    }
                    Sort.descendingSort(numbers);
                } else if (line.equals("Exit")) {
                    writeUsingFileWriter("Finished...");
                    System.out.println("Finished...");
                    return;
                } else {
                    System.out.println("Invalid input: " + line);
                }
            }
        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
    }
}

