import java.util.ArrayList;
import java.util.List;

public class EmripNumbers {
    public static boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }
        for (int j = 2; j <= Math.sqrt(n); j++) {
            if (n % j == 0) {
                return false;
            }
        }
        return true;
    }

    public static void printEmripNumbers(int max) {
        System.out.println("Emrip numbers until " + max + ":");
        Main.writeUsingFileWriter("Emrip numbers until " + max + ":\n");
        List<String> primes = new ArrayList<>();
        for (int i = 2; i <= max; i++) {
            if (isPrime(i)) {
                primes.add(Integer.toString(i));
            }
        }
        for (String k : primes) {
            int l = k.length();
            if (l == 1) {
                continue;
            } else {
                int rev_k = Integer.parseInt(new StringBuilder(k).reverse().toString());
                if (isPrime(rev_k) && Integer.parseInt(k) != rev_k) {
                    String result = k + " ";
                    Main.writeUsingFileWriter(result);
                    System.out.print(k + " ");
                }
            }
        }
        Main.writeUsingFileWriter(Main.tline);
        System.out.println();
    }
}
