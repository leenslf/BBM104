public class ArmstrongNumbers {
    public static void printArmstrongNumbers(int n) {
        System.out.println("Armstrong numbers up to " + n + ":");
        Main.writeUsingFileWriter("Armstrong numbers up to " + n + ":\n");
        for (int i = 1; i <= n; i++) {
            int length = String.valueOf(i).length();
            if (length == 1) {
                String result = i + " ";
                Main.writeUsingFileWriter(result);
                System.out.print(i + " ");
            } else {
                String strn = String.valueOf(i);
                int sum = 0;
                for (int k = 0; k < length; k++) {
                    sum += Math.pow(Integer.parseInt(String.valueOf(strn.charAt(k))), length);
                }
                if (sum == i) {
                    String result = i + " ";
                    Main.writeUsingFileWriter(result);
                    System.out.print(i + " ");
                }
            }
        }
        Main.writeUsingFileWriter(Main.tline);
        System.out.println();
    }
}
