import java.util.ArrayList;
import java.util.List;

public class AbundantNumbers {
    public static boolean isAbundantNumber(int n) {
        List<Integer> factors = new ArrayList<>();
        for (int i = 1; i < n; i++) {
            if (n % i == 0) {
                factors.add(i);
            }
        }
        int sum = 0;
        for (int factor : factors) {
            sum += factor;
        }
        return sum > n;
    }
    public static void printAbundantNumbers(int max) {
        System.out.println("Abundant numbers until " + max + ":");
        Main.writeUsingFileWriter("Abundant numbers until " + max + ":\n");
        for (int k = 1; k <= max; k++) {
            if (isAbundantNumber(k)) {
                String result = k + " ";
                Main.writeUsingFileWriter(result);
                System.out.print(k + " ");
            }
        }
        Main.writeUsingFileWriter(Main.tline);
        System.out.println();
    }
}
