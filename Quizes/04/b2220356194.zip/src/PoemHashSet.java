import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;

public class PoemHashSet {
    public static HashSet<String> poemHashSet(String path) {
        try {
            Path path1 = Paths.get(path);
            HashSet<String> poemHashSet = new HashSet<>();
            for (String line : Files.readAllLines(path1)) {
                poemHashSet.add(line);
            }
            return poemHashSet;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
