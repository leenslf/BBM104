import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class PoemArrayList {
    public static ArrayList<String> poemArrayList(String path) {
        try {
            Path path1 = Paths.get(path);
            ArrayList<String> poemArrayList = new ArrayList<>();
            for (String line : Files.readAllLines(path1)) {
                poemArrayList.add(line);
            }
            return poemArrayList;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
