import java.util.Comparator;

public class IDComparator implements Comparator<String> {

    @Override
    public int compare(String s1, String s2) {
        // Extract the numbers at the beginning of each string
        int num1 = extractNumber(s1);
        int num2 = extractNumber(s2);

        // Compare the numbers
        return Integer.compare(num1, num2);
    }

    private int extractNumber(String s) {
        // Find the first digit in the string
        int index = 0;
        while (index < s.length() && !Character.isDigit(s.charAt(index))) {
            index++;
        }

        // Extract the number from the string
        int num = 0;
        while (index < s.length() && Character.isDigit(s.charAt(index))) {
            num = num * 10 + Character.getNumericValue(s.charAt(index));
            index++;
        }

        return num;
    }

}
