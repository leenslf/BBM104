import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;


public class PoemHashMap {
    public static HashMap<Integer, String> poemHashMap(String path) {
        try {
            Path path1 = Paths.get(path);
            HashMap<Integer, String> poemHashMap = new HashMap<>();
            for (String line : Files.readAllLines(path1)) {
                int id = extractNumber(line);
                String pLine = extractLine(line);
                poemHashMap.put(id, pLine);
            }
            return poemHashMap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    private static int extractNumber(String s) {
        // Find the first digit in the string
        int index = 0;
        while (index < s.length() && !Character.isDigit(s.charAt(index))) {
            index++;
        }

        // Extract the number from the string
        int num = 0;
        while (index < s.length() && Character.isDigit(s.charAt(index))) {
            num = num * 10 + Character.getNumericValue(s.charAt(index));
            index++;
        }

        return num;
    }

    private static String extractLine(String s) {
        // Find the first character in the string
        int index = 0;
        while (index < s.length() && Character.isDigit(s.charAt(index))) {
            index++;
        }
        // Extract the line from the string
        StringBuilder sb = new StringBuilder();
        while (index < s.length()){
            sb.append(s.charAt(index));
            index++;
        }
        return String.valueOf(sb);
    }

}
