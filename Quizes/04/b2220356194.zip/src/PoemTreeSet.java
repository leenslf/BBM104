import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;
import java.util.TreeSet;

public class PoemTreeSet {
    Set<String> poemTreeSet = new TreeSet<>();
    Set<String> poemTreeSetComparator = new TreeSet<>(new IDComparator());

    public PoemTreeSet(String path) {
        try {
            Path path1 = Paths.get(path);
            for (String line : Files.readAllLines(path1)) {
                poemTreeSet.add(line);
                poemTreeSetComparator.add(line); // add the line to both sets
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Set<String> getPoemTreeSet() {
        return poemTreeSet;
    }

    public Set<String> getPoemTreeSetComparator() {
        return poemTreeSetComparator;
    }
}

