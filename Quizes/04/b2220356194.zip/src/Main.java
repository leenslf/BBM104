import java.util.*;

public class Main {
    public static void main(String[] args) {

        String path = args[0];
        Writer<String> writer = new Writer<>();

        ArrayList<String> poemArrayList =  PoemArrayList.poemArrayList(path);
        assert poemArrayList != null;
        writer.writeToFile(poemArrayList,"poemArrayList.txt");

        Collections.sort(poemArrayList, new IDComparator());
        writer.writeToFile(poemArrayList,"poemArrayListOrderByID.txt");

        HashSet<String> poemHashSet = PoemHashSet.poemHashSet(path);
        assert poemHashSet != null;
        writer.writeToFile(poemHashSet,"poemHashSet.txt");

        PoemTreeSet poemTreeSet = new PoemTreeSet(path);
        assert poemTreeSet != null;
        writer.writeToFile(poemTreeSet.getPoemTreeSet(),"poemTreeSet.txt");
        writer.writeToFile(poemTreeSet.getPoemTreeSetComparator()," poemTreeSetOrderByID.txt");

        HashMap<Integer, String> poemHashMap = PoemHashMap.poemHashMap(path);
        assert poemHashMap != null;
        writer.writeToFile(poemHashMap, "poemHashMap.txt");

    }
}