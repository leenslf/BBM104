import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Writer<T> {
    public void writeToFile(Collection<T> collection, String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (T element : collection) {
                writer.write(element.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeToFile(HashMap<Integer, String> hashmap, String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (Map.Entry<Integer, String> entry : hashmap.entrySet()) {
                Integer key = entry.getKey();
                String value = entry.getValue();
                writer.write(key + "  " + value+ "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
